




import React, { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginComponent from './core/LoginComponent';
import HomeComponent from './core/HomeComponent';
import CandidateregistraionComponent from './core/CandidateregistraionComponent';
import ListAllCandidate from './core/ListAllCandidate';
import Sidebar from './core/Sidebar';
import ListallJobs from './core/Listalljobs';
import Scheduledinterviews from './core/Scheduledinterviews';
// import ScheduledInterview from './core/ScheduledInterview';
import ScheduledInterview from './core/SchedluedInterview';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [role, setRole] = useState("");
  const [userEmail, setUserEmail] = useState("");

  return (
    <div style={{ display: "flex" }}>
      <BrowserRouter>
        {role && <Sidebar role={role} />}
        <Routes>
          <Route path="/" element={<LoginComponent setRole={setRole} setUserEmail={setUserEmail} />} />
          <Route path="/CandidateComponent" element={<CandidateregistraionComponent />} />
          <Route path="/HomeComponent" element={<HomeComponent />} />
          <Route path="/ListAllCandidate" element={<ListAllCandidate />} />
          <Route path="/Listalljobs" element={<ListallJobs />} />
          <Route path="/Scheduledinterviews" element={<Scheduledinterviews />} />
          <Route path="/ScheduledInterview" element={<ScheduledInterview userEmail={userEmail} />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;



