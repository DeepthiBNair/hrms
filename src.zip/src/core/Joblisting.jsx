import React, { useState } from 'react';
import AddJobModal from './AddJobModal'; // Import the modal component

const JobListing = () => {
    const [show, setShow] = useState(false);
    const [jobs, setJobs] = useState([
        {
            jobName: 'Software Engineer',
            location: 'Mumbai',
            jobType: 'Full Time',
            postedDate: 'Posted: 1 Day Ago',
            jobDescription: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
            company: 'uknowva',
            role: 'Programmer',
            roleCategory: 'Computer and information technology',
            positions: '01',
            experience: 'Entry level (<2 years)',
        },
    ]);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const handleAddJob = (newJob) => {
        setJobs([...jobs, newJob]);
    };

    return (
        <div className="job-listing">
            {jobs.map((job, index) => (
                <div key={index} className="job-item">
                    <div className="job-title">
                        <h2>{job.jobName}</h2>
                    </div>
                    <div className="job-details">
                        <p className="location">{job.location}</p>
                        <p className="job-type">{job.jobType}</p>
                        <p className="posted-date">{job.postedDate}</p>
                    </div>
                    <div className="job-description">
                        <h3>About This Job</h3>
                        <p>{job.jobDescription}</p>
                    </div>
                    <div className="company-info">
                        <h3>Company</h3>
                        <p>{job.company}</p>
                        <h3>Role</h3>
                        <p>{job.role}</p>
                        <h3>Role Category</h3>
                        <p>{job.roleCategory}</p>
                    </div>
                    <div className="job-stats">
                        <h3>Job Stats</h3>
                        <p>Positions: {job.positions}</p>
                        <p>Experience: {job.experience}</p>
                    </div>
                    <div className="application-details">
                        <h3>Apply Now</h3>
                        <a href="#">Refer a candidate</a>
                        <a href="#">Email to a friend</a>
                    </div>
                </div>
            ))}
            <button onClick={handleShow}>Add Job</button>
            <AddJobModal show={show} handleClose={handleClose} handleAddJob={handleAddJob} />
        </div>
    );
};

export default JobListing;
