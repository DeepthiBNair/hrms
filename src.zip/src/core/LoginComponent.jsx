




// import { useState } from "react";
// import axios from "axios";
// import { useNavigate, Link } from "react-router-dom";
// import { toast, ToastContainer } from "react-toastify";
// import './Login.css';

// function LoginComponent({ setRole, setUserEmail }) {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [emailError, setEmailError] = useState("");
//   const [passwordError, setPasswordError] = useState("");
//   const navigate = useNavigate();

//   async function login(event) {
//     event.preventDefault();

//     if (!email) {
//       setEmailError("Email is required");
//     } else if (!/\S+@\S+\.\S+/.test(email)) {
//       setEmailError("Enter a valid email address");
//     } else {
//       setEmailError("");
//     }

//     if (!password) {
//       setPasswordError("Password is required");
//     } else {
//       setPasswordError("");
//     }

//     if (!email || !password || !/\S+@\S+\.\S+/.test(email)) {
//       return;
//     }
//     try {
//       const response = await axios.post("http://localhost:8080/login/role", {
//         email: email,
//         password: password,
//       });

//       console.log(response.data);
//       const role = response.data;

//       if (role === 'user is admin') {
//         setRole("admin");
//         setUserEmail(email);
//         navigate('/Sidebar');
//       } else if (role === 'user is an employee') {
//         setRole("employee");
//         setUserEmail(email);
//         navigate('/ScheduledInterview');
//       } else {
//         toast.error("Invalid email or password");
//       }
//     } catch (error) {
//       console.error('Error logging in:', error);
//       toast.error("Invalid email or password");
//     }
//   };

//   return (
//     <div className="container">
//       <div className="row justify-content-center align-items-center">
//         <div className="col-md-4 border p-4">
//           <h2 className="text-center">Login here</h2>
//           <form>
//             <div className="mt-5">
//               <div className="form-group">
//                 <label className="control-label">Email</label>
//                 <input
//                   type="text"
//                   placeholder="Enter your email"
//                   className={`form-control ${
//                     emailError ? "border border-danger" : ""
//                   }`}
//                   value={email}
//                   onChange={(event) => setEmail(event.target.value)}
//                 />
//                 {emailError && (
//                   <p className="text-danger mt-2">{emailError}</p>
//                 )}
//               </div>
//             </div>
//             <div className="mt-3">
//               <div data-mdb-input-init className="form-outline mb-4">
//                 <div className="form-group">
//                   <label className="control-label">Password</label>
//                   <input
//                     type="password"
//                     placeholder="Enter your password"
//                     className={`form-control ${
//                       passwordError ? "border border-danger" : ""
//                     }`}
//                     value={password}
//                     onChange={(event) => setPassword(event.target.value)}
//                   />
//                   {passwordError && (
//                     <p className="text-danger mt-2">{passwordError}</p>
//                   )}
//                 </div>
//               </div>
//             </div>
//             <div className="form-group text-center">
//               <div className="mt-3">
//                 <div className="mb-1">
//                   <input
//                     type="submit"
//                     value="Login"
//                     onClick={login}
//                     className="btn btn-primary btn-block"
//                   />
//                 </div>
//               </div>
//             </div>
//           </form>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default LoginComponent;






import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import './Login.css';

function LoginComponent({ setRole, setUserEmail }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const navigate = useNavigate();

  async function login(event) {
    event.preventDefault();

    if (!email) {
      setEmailError("Email is required");
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      setEmailError("Enter a valid email address");
    } else {
      setEmailError("");
    }

    if (!password) {
      setPasswordError("Password is required");
    } else {
      setPasswordError("");
    }

    if (!email || !password || !/\S+@\S+\.\S+/.test(email)) {
      return;
    }
    try {
      const response = await axios.post("http://localhost:8080/login/role", {
        email: email,
        password: password,
      });

      console.log(response.data);
      const role = response.data;

      if (role === 'user is admin') {
        setRole("admin");
        setUserEmail(email);
        navigate('/ListAllCandidate');
      } else if (role === 'user is an employee') {
        setRole("employee");
        setUserEmail(email);
        navigate('/ScheduledInterview');
      } else {
        toast.error("Invalid email or password");
      }
    } catch (error) {
      console.error('Error logging in:', error);
      toast.error("Invalid email or password");
    }
  };

  return (
    <div className="login-container">
      <h2>Login here</h2>
      <form>
        <div className="input-container">
          <input
            type="text"
            placeholder="Enter your email"
            className={`form-control ${
              emailError ? "border border-danger" : ""
            }`}
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
          {emailError && <p className="text-danger mt-2">{emailError}</p>}
        </div>
        <div className="input-container">
          <input
            type="password"
            placeholder="Enter your password"
            className={`form-control ${
              passwordError ? "border border-danger" : ""
            }`}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
          {passwordError && <p className="text-danger mt-2">{passwordError}</p>}
        </div>
        <button type="submit" onClick={login}>
          Login
        </button>
      </form>
    </div>
  );
}

export default LoginComponent;
