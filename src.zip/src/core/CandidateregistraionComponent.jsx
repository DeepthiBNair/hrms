

// const CandidateregistraionComponent = () => {
//   return (
//     <div>CandidateregistraionComponent</div>
//   )
// }

// export default CandidateregistraionComponent



// import React, { useState } from 'react';
// import Dropzone from 'react-dropzone';
// import axios from 'axios';
// import './Candidateregistration.css';

// const RegistrationForm = () => {
//   const [formData, setFormData] = useState({
//     name: '',
//     phone: '',
//     email: '',
//     designation: '',
//     qualification:'',
//     resume: null
//   });

//   const handleChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value
//     });
//   };

//   const handleFileUpload = (acceptedFiles) => {
//     setFormData({
//       ...formData,
//       resume: acceptedFiles[0]
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
    
//     const data = new FormData();
//     data.append('name', formData.name);
//     data.append('phone', formData.phone);
//     data.append('email', formData.email);
//     data.append('designation', formData.designation);
//     data.append('qualification',formData.qualification);
//     data.append('resume', formData.resume);

//     try {
//       const response = await axios.post('http://localhost:8080/api/candidates', data);
//       console.log(response.data);
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   return (
//     <form onSubmit={handleSubmit}>
//       <div>
//         <label>Name:</label>
//         <input type="text" name="name" value={formData.name} onChange={handleChange} required />
//       </div>
//       <div>
//         <label>Phone Number:</label>
//         <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required />
//       </div>
//       <div>
//         <label>Email:</label>
//         <input type="email" name="email" value={formData.email} onChange={handleChange} required />
//       </div>
//       <div>
//         <label>Designation:</label>
//         <input type="text" name="designation" value={formData.designation} onChange={handleChange} required />
//       </div>
//       <div>
//         <label>Heightest Qualification:</label>
//         <input type="text" name="qualification" value={formData.qualification} onChange={handleChange}required/>
//       </div>
//       <div>
//         <label>Resume (PDF):</label>
//         <Dropzone onDrop={handleFileUpload} accept=".pdf">
//           {({getRootProps, getInputProps}) => (
//             <div {...getRootProps()} style={{border: '1px solid black', padding: '20px'}}>
//               <input {...getInputProps()} />
//               {formData.resume ? <p>{formData.resume.name}</p> : <p>Drag 'n' drop a PDF file here, or click to select one</p>}
//             </div>
//           )}
//         </Dropzone>
//       </div>
//       <button type="submit">Register</button>
//     </form>
//   );
// };

// export default RegistrationForm;


import React, { useState } from 'react';
import Dropzone from 'react-dropzone';
import axios from 'axios';
// import Sidebar from './Sidebar';
// import { useNavigate } from 'react-router-dom';

const CandidateregistraionComponent = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    designation: '',
    qualification:'',
    resume: null
  
  });
//   const navigate = useNavigate();
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleFileUpload = (acceptedFiles) => {
    setFormData({
      ...formData,
      resume: acceptedFiles[0]
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const data = new FormData();
    data.append('name', formData.name);
    data.append('phone', formData.phone);
    data.append('email', formData.email);
    data.append('designation', formData.designation);
    data.append('qualification', formData.qualification);
    data.append('resume', formData.resume);

    try {
      const response = await axios.post('http://localhost:8080/api/candidates', data);
      console.log(response.data);
    //   navigate('/');
    } catch (error) {
      console.error(error);
    }
  };

  const styles = {
    formContainer: {
      maxWidth: '600px',
      margin: '0 auto',
      padding: '20px',
      border: '1px solid #ccc',
      borderRadius: '10px',
      backgroundColor: '#f9f9f9',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    },
    formGroup: {
      marginBottom: '15px',
    },
    label: {
      display: 'block',
      marginBottom: '5px',
      fontWeight: 'bold',
    },
    input: {
      width: '100%',
      padding: '8px',
      border: '1px solid #ccc',
      borderRadius: '5px',
      boxSizing: 'border-box',
    },
    dropzone: {
      border: '2px dashed #ccc',
      borderRadius: '5px',
      padding: '20px',
      textAlign: 'center',
      backgroundColor: '#fafafa',
      cursor: 'pointer',
    },
    dropzoneText: {
      margin: '0',
      fontSize: '16px',
      color: '#666',
    },
    submitButton: {
      width: '100%',
      padding: '10px',
      border: 'none',
      borderRadius: '5px',
      backgroundColor: '#4CAF50',
      color: 'white',
      fontSize: '16px',
      cursor: 'pointer',
    },
    submitButtonHover: {
      backgroundColor: '#45a049',
    },
  };

  return (
    <div>
{/* <Sidebar/> */}
    
    <form style={styles.formContainer} onSubmit={handleSubmit}>
      <div style={styles.formGroup}>
        <label style={styles.label}>Name:</label>
        <input type="text" name="name" value={formData.name} onChange={handleChange} required style={styles.input} />
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Phone Number:</label>
        <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required style={styles.input} />
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Email:</label>
        <input type="email" name="email" value={formData.email} onChange={handleChange} required style={styles.input} />
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Designation:</label>
        <input type="text" name="designation" value={formData.designation} onChange={handleChange} required style={styles.input} />
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Highest Qualification:</label>
        <input type="text" name="qualification" value={formData.qualification} onChange={handleChange} required style={styles.input} />
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Resume (PDF):</label>
        <Dropzone onDrop={handleFileUpload} accept=".pdf">
          {({ getRootProps, getInputProps }) => (
            <div {...getRootProps()} style={styles.dropzone}>
              <input {...getInputProps()} />
              {formData.resume ? <p style={styles.dropzoneText}>{formData.resume.name}</p> : <p style={styles.dropzoneText}>Drag 'n' drop a PDF file here, or click to select one</p>}
            </div>
          )}
        </Dropzone>
      </div>
      <button type="submit" style={styles.submitButton}>Register</button>
    </form>
    </div>
  );
};

export default CandidateregistraionComponent
