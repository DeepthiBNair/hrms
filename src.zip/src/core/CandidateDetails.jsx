import React from "react";
import { Modal, Button } from "react-bootstrap";

function CandidateDetails({ show, handleClose, candidate }) {
  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Interview Details of {candidate.name}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>Status: {candidate.status}</p>
        <p>Result: {candidate.result ? candidate.result : 'Pending'}</p>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>Close</Button>
        <Button variant="secondary">Hire</Button>
        <Button variant="secondary">Reject</Button>
      </Modal.Footer>
    </Modal>
  );
}

export default CandidateDetails;
