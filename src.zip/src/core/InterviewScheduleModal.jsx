




// import React, { useState, useEffect } from 'react';
// import { Modal, Button, Form, Alert } from 'react-bootstrap';
// import axios from 'axios';

// const InterviewScheduleModal = ({ show, handleClose, candidate, updateCandidateList }) => {
//     const [form, setForm] = useState({
//         candidateName: '',
//         interviewerName: '',
//         interviewDate: '',
//         interviewTime: '',
//         candidateEmail: '',
//         interviewerEmail: '',
//         interviewMode: '',
//         meetingLink: 'https://meet.google.com/uio-ucmf-hxa' // Default meeting link
//     });

//     const [scheduled, setScheduled] = useState(false);

//     useEffect(() => {
//         if (candidate) {
//             setForm({
//                 ...form,
//                 candidateName: candidate.name || '',
//                 candidateEmail: candidate.email || ''
//             });
//         }
//     }, [candidate]);

//     const handleChange = (e) => {
//         setForm({ ...form, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         try {
//             await axios.post(`http://localhost:8080/api/interviewschedules`, {
//                 candidateId: candidate.id,
//                 candidateName: form.candidateName,
//                 interviewerName: form.interviewerName,
//                 interviewDate: form.interviewDate,
//                 interviewTime: form.interviewTime,
//                 candidateEmail: form.candidateEmail,
//                 interviewerEmail: form.interviewerEmail,
//                 interviewMode: form.interviewMode,
//                 meetingLink: form.meetingLink
//             });

//             // Update the parent component's state to reflect the scheduling
//             updateCandidateList({
//                 ...candidate,
//                 status: 'Scheduled'
//             });

//             setScheduled(true); // Set scheduled state to true on success
//         } catch (error) {
//             console.error('Error scheduling interview:', error);
//         }
//     };

//     const resetForm = () => {
//         setForm({
//             candidateName: candidate.name || '',
//             interviewerName: '',
//             interviewDate: '',
//             interviewTime: '',
//             candidateEmail: candidate.email || '',
//             interviewerEmail: '',
//             interviewMode: '',
//             meetingLink: 'https://meet.google.com/uio-ucmf-hxa'
//         });
//         setScheduled(false); // Reset scheduled state
//         handleClose(); // Close the modal
//     };

//     return (
//         <Modal show={show} onHide={handleClose}>
//             <Modal.Header closeButton>
//                 <Modal.Title>Schedule Interview</Modal.Title>
//             </Modal.Header>
//             <Modal.Body>
//                 {!scheduled ? (
//                     <Form onSubmit={handleSubmit}>
//                         <Form.Group className="mb-3">
//                             <Form.Label>Candidate Name</Form.Label>
//                             <Form.Control
//                                 type="text"
//                                 name="candidateName"
//                                 value={form.candidateName}
//                                 onChange={handleChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group className="mb-3">
//                             <Form.Label>Candidate Email</Form.Label>
//                             <Form.Control
//                                 type="email"
//                                 name="candidateEmail"
//                                 value={form.candidateEmail}
//                                 onChange={handleChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group className="mb-3">
//                             <Form.Label>Interviewer Name</Form.Label>
//                             <Form.Control
//                                 type="text"
//                                 name="interviewerName"
//                                 value={form.interviewerName}
//                                 onChange={handleChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group className="mb-3">
//                             <Form.Label>Interviewer Email</Form.Label>
//                             <Form.Control
//                                 type="email"
//                                 name="interviewerEmail"
//                                 value={form.interviewerEmail}
//                                 onChange={handleChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group className="mb-3">
//                             <Form.Label>Interview Date</Form.Label>
//                             <Form.Control
//                                 type="date"
//                                 name="interviewDate"
//                                 value={form.interviewDate}
//                                 onChange={handleChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group className="mb-3">
//                             <Form.Label>Interview Time</Form.Label>
//                             <Form.Control
//                                 type="time"
//                                 name="interviewTime"
//                                 value={form.interviewTime}
//                                 onChange={handleChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group className="mb-3">
//                             <Form.Label>Interview Mode</Form.Label>
//                             <Form.Control
//                                 type="text"
//                                 name="interviewMode"
//                                 value={form.interviewMode}
//                                 onChange={handleChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group className="mb-3">
//                             <Form.Label>Meeting Link</Form.Label>
//                             <Form.Control
//                                 type="text"
//                                 name="meetingLink"
//                                 value={form.meetingLink}
//                                 onChange={handleChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Button variant="primary" type="submit">
//                             Schedule
//                         </Button>
//                     </Form>
//                 ) : (
//                     <Alert variant="success">
//                         Interview scheduled successfully!
//                     </Alert>
//                 )}
//             </Modal.Body>
//             <Modal.Footer>
//                 <Button variant="secondary" onClick={resetForm}>
//                     {scheduled ? "Close" : "Cancel"}
//                 </Button>
//             </Modal.Footer>
//         </Modal>
//     );
// };

// export default InterviewScheduleModal;















import React, { useState, useEffect } from 'react';
import { Modal, Button, Form, Alert } from 'react-bootstrap';
import axios from 'axios';

const InterviewScheduleModal = ({ show, handleClose, candidate, updateCandidateList }) => {
    const [form, setForm] = useState({
        candidateName: '',
        candidateEmail: '',
        interviewerEmail: '',
        interviewerName: '',
        interviewer2: '',
        interviewer2Email: '',
        interviewDate: '',
        interviewTime: '',
        interviewMode: '',
        meetingLink: 'https://meet.google.com/uio-ucmf-hxa' // Default meeting link
    });

    const [scheduled, setScheduled] = useState(false);

    useEffect(() => {
        if (candidate) {
            setForm((prevForm) => ({
                ...prevForm,
                candidateName: candidate.name || '',
                candidateEmail: candidate.email || ''
            }));
        }
    }, [candidate]);

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post(`http://localhost:8080/api/interviewschedules`, {
                candidateId: candidate.id,
                candidateName: form.candidateName,
                interviewerName: form.interviewerName,
                interviewerEmail: form.interviewerEmail,
                interviewer2: form.interviewer2,
                interviewer2Email: form.interviewer2Email,
                interviewDate: form.interviewDate,
                interviewTime: form.interviewTime,
                candidateEmail: form.candidateEmail,
                interviewMode: form.interviewMode,
                meetingLink: form.meetingLink
            });

            // Update the parent component's state to reflect the scheduling
            updateCandidateList({
                ...candidate,
                status: 'Scheduled'
            });

            setScheduled(true); // Set scheduled state to true on success
        } catch (error) {
            console.error('Error scheduling interview:', error);
        }
    };

    const resetForm = () => {
        setForm({
            candidateName: candidate.name || '',
            candidateEmail: candidate.email || '',
            interviewerName: '',
            interviewerEmail: '',
            interviewer2: '',
            interviewer2Email: '',
            interviewDate: '',
            interviewTime: '',
            interviewMode: '',
            meetingLink: 'https://meet.google.com/uio-ucmf-hxa'
        });
        setScheduled(false); // Reset scheduled state
        handleClose(); // Close the modal
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Schedule Interview</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                {!scheduled ? (
                    <Form onSubmit={handleSubmit}>
                        <Form.Group className="mb-3">
                            <Form.Label>Candidate Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="candidateName"
                                value={form.candidateName}
                                onChange={handleChange}
                                required
                                disabled
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Candidate Email</Form.Label>
                            <Form.Control
                                type="email"
                                name="candidateEmail"
                                value={form.candidateEmail}
                                onChange={handleChange}
                                required
                                disabled
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Interviewer 1 Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="interviewerName"
                                value={form.interviewerName}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Interviewer 1 Email</Form.Label>
                            <Form.Control
                                type="email"
                                name="interviewerEmail"
                                value={form.interviewerEmail}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Interviewer 2 Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="interviewer2"
                                value={form.interviewer2}
                                onChange={handleChange}
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Interviewer 2 Email</Form.Label>
                            <Form.Control
                                type="email"
                                name="interviewer2Email"
                                value={form.interviewer2Email}
                                onChange={handleChange}
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Interview Date</Form.Label>
                            <Form.Control
                                type="date"
                                name="interviewDate"
                                value={form.interviewDate}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Interview Time</Form.Label>
                            <Form.Control
                                type="time"
                                name="interviewTime"
                                value={form.interviewTime}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Interview Mode</Form.Label>
                            <Form.Control
                                type="text"
                                name="interviewMode"
                                value={form.interviewMode}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Meeting Link</Form.Label>
                            <Form.Control
                                type="text"
                                name="meetingLink"
                                value={form.meetingLink}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Button variant="primary" type="submit">
                            Schedule
                        </Button>
                    </Form>
                ) : (
                    <Alert variant="success">
                        Interview scheduled successfully!
                    </Alert>
                )}
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={resetForm}>
                    {scheduled ? "Close" : "Cancel"}
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

export default InterviewScheduleModal;
