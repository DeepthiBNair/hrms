import React, { useState, useEffect } from 'react';
import { Modal, Button, Dropdown, DropdownButton } from 'react-bootstrap';
import axios from 'axios';

function CandidateDetailsTab({ candidate, handleClose, updateCandidateList }) {
  const [remarks, setRemarks] = useState([]);

  useEffect(() => {
    fetchRemarks(candidate.id);
  }, [candidate.id]);

  const fetchRemarks = async (candidateId) => {
    try {
      const response = await axios.get(`http://localhost:8080/api/interview-remarks/candidate/${candidateId}`);
      setRemarks(response.data);
    } catch (error) {
      console.error('Error fetching remarks:', error);
    }
  };

  const handleStatusChange = async (status) => {
    try {
      const updatedCandidate = { ...candidate, status };
      await axios.put(`http://localhost:8080/api/candidates/${candidate.id}`, updatedCandidate);
      updateCandidateList(updatedCandidate);
      handleClose();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  return (
    <Modal show={true} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Details of {candidate.name}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p><strong>Phone:</strong> {candidate.phone}</p>
        <p><strong>Email:</strong> {candidate.email}</p>
        <p><strong>Designation:</strong> {candidate.designation}</p>
        <p><strong>Qualification:</strong> {candidate.qualification}</p>
        <p><strong>Status:</strong> {candidate.status}</p>
        <p><strong>Remarks:</strong></p>
        {remarks.length > 0 ? (
          remarks.map((remark, index) => (
            <div key={index}>
              <p><strong>{remark.interviewerName}:</strong> {remark.remark}</p>
            </div>
          ))
        ) : (
          <p>No remarks available.</p>
        )}
        <DropdownButton id="dropdown-basic-button" title="Update Status">
          <Dropdown.Item onClick={() => handleStatusChange("Shortlisted")}>Shortlisted</Dropdown.Item>
          <Dropdown.Item onClick={() => handleStatusChange("Rejected")}>Rejected</Dropdown.Item>
          <Dropdown.Item onClick={() => handleStatusChange("Will use in future")}>Will use in future</Dropdown.Item>
          <Dropdown.Item onClick={() => handleStatusChange("Shortlisted but high package")}>Shortlisted but high package</Dropdown.Item>
        </DropdownButton>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>Close</Button>
      </Modal.Footer>
    </Modal>
  );
}

export default CandidateDetailsTab;
