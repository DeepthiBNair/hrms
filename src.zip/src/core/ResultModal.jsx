






import React, { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import axios from 'axios';

const ResultModal = ({ show, handleClose, interview, onSave }) => {
    const [communication, setCommunication] = useState("");
    const [pratctical, setPracticalKnowledge] = useState("");
    const [therotical, setTheoreticalKnowledge] = useState("");
    const [overall, setOverall] = useState("");
    const [result, setResult] = useState(null);

    const determineResult = () => {
        // Example logic to determine pass/fail
        if (
            communication === "excellent" ||
            pratctical === "excellent" ||
            overall === "excellent" ||
            therotical === "excellent"
        ) {
            return "Pass";
        }
        return "Fail";
    };

    const handleSave = async () => {
        const resultData = {
            candidateId: interview.candidateId,
            candidateName: interview.candidateName,
            communication,
            pratctical,
            overall,
            therotical,
            result: determineResult() // Determine and add the result to the data
        };
        setResult(resultData.result); // Set the result state

        try {
             await axios.put(`http://localhost:8080/api/candidates/${interview.candidateId}/result`, resultData);
            // await axios.put("http://localhost:8080/api/candidates/$/{id},/result",resultData)
            onSave(resultData); // Pass resultData to parent component onSave function if needed
        } catch (error) {
            console.error('Error saving result:', error);
        }

        handleClose(); // Close the modal after saving or if there's an error
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Add Result for {interview.candidateName}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Group controlId="communication">
                        <Form.Label>Communication Level</Form.Label>
                        <Form.Control as="select" value={communication} onChange={e => setCommunication(e.target.value)}>
                            <option value="">Select</option>
                            <option value="excellent">Excellent</option>
                            <option value="good">Good</option>
                            <option value="average">Average</option>
                            <option value="bad">Bad</option>
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="pratctical" className="mt-3">
                        <Form.Label>Practical Knowledge</Form.Label>
                        <Form.Control as="select" value={pratctical} onChange={e => setPracticalKnowledge(e.target.value)}>
                            <option value="">Select</option>
                            <option value="excellent">Excellent</option>
                            <option value="good">Good</option>
                            <option value="average">Average</option>
                            <option value="bad">Bad</option>
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="overall" className="mt-3">
                        <Form.Label>Overall Performance</Form.Label>
                        <Form.Control as="select" value={overall} onChange={e => setOverall(e.target.value)}>
                            <option value="">Select</option>
                            <option value="excellent">Excellent</option>
                            <option value="good">Good</option>
                            <option value="average">Average</option>
                            <option value="bad">Bad</option>
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="therotical" className="mt-3">
                        <Form.Label>Theoretical Knowledge</Form.Label>
                        <Form.Control as="select" value={therotical} onChange={e => setTheoreticalKnowledge(e.target.value)}>
                            <option value="">Select</option>
                            <option value="excellent">Excellent</option>
                            <option value="good">Good</option>
                            <option value="average">Average</option>
                            <option value="bad">Bad</option>
                        </Form.Control>
                    </Form.Group>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                    Close
                </Button>
                <Button variant="primary" onClick={handleSave}>
                    Save Changes
                </Button>
                {result && (
                    <Button variant={result === "Pass" ? "success" : "danger"}>
                        {result}
                    </Button>
                )}
            </Modal.Footer>
        </Modal>
    );
};

export default ResultModal;
