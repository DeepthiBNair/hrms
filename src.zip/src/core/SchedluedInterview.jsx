













// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { Modal, Card } from 'react-bootstrap';
// import './UserPage.css';

// const ScheduledInterview = ({ userEmail, userType }) => {
//     const [response1, setResponse1] = useState([]);
//     const [response2, setResponse2] = useState([]);
//     const [showModal, setShowModal] = useState(false);
//     const [selectedInterview, setSelectedInterview] = useState(null);
//     const [remarks, setRemarks] = useState([]);
//     const [newRemark, setNewRemark] = useState('');
//     const [interviewerName, setInterviewerName] = useState('');
//     const [showResultModal, setShowResultModal] = useState(false);
//     const [showCard, setShowCard] = useState(false);

//     useEffect(() => {
//         if (userEmail) {
//             fetchScheduledInterviews(userEmail);
//         }
//     }, [userEmail]);

//     const fetchScheduledInterviews = async (email) => {
//         try {
//             const response1 = await axios.get(`http://localhost:8080/api/interviewschedules/interviewer/${email}`);
//             const response2 = await axios.get(`http://localhost:8080/api/interviewschedules/interviewer2/${email}`);
            
//             setResponse1(response1.data);
//             setResponse2(response2.data);
//         } catch (error) {
//             console.error('Error fetching scheduled interviews:', error);
//         }
//     };

//     const handleResult = (interview) => {
//         setSelectedInterview(interview);
//         setShowModal(true);
//     };

//     const handleCloseModal = () => {
//         setShowModal(false);
//         setSelectedInterview(null);
//     };

//     const handleViewResult = async (interview) => {
//         setSelectedInterview(interview);
//         await fetchRemarks(interview.id);
//         setShowResultModal(true);
//     };

//     const fetchRemarks = async (interviewId) => {
//         try {
//             const response = await axios.get(`http://localhost:8080/api/interview-remarks/interview/${interviewId}/interviewer/${userEmail}`);
//             setRemarks(response.data);
//         } catch (error) {
//             console.error('Error fetching remarks:', error);
//         }
//     };

//     const handleAddRemark = async () => {
//         if (newRemark.trim() === '' || interviewerName.trim() === '') return;
//         try {
//             const response = await axios.post('http://localhost:8080/api/interview-remarks', {
//                 candidate: { id: selectedInterview.candidateId },
//                 interview: { id: selectedInterview.id },
//                 interviewerName,
//                 interviewerEmail: userEmail,
//                 remark: newRemark,
//                 timestamp: new Date().toISOString()
//             });
//             setRemarks([...remarks, response.data]);
//             setNewRemark('');
//             setInterviewerName('');

//             const updatedInterviews1 = response1.map(interview =>
//                 interview.id === selectedInterview.id ? { ...interview, remarksAdded: true } : interview
//             );
//             const updatedInterviews2 = response2.map(interview =>
//                 interview.id === selectedInterview.id ? { ...interview, remarksAdded: true } : interview
//             );

//             setResponse1(updatedInterviews1);
//             setResponse2(updatedInterviews2);

//             // Update interview status to "Interview Done"
//             await axios.put(`http://localhost:8080/api/interviewschedules/${selectedInterview.id}`, {
//                 ...selectedInterview,
//                 status: "Interview Done"
//             });

//         } catch (error) {
//             console.error('Error adding remark:', error);
//         }
//     };

//     const handleCloseResultModal = () => {
//         setShowResultModal(false);
//         setSelectedInterview(null);
//         setRemarks([]);
//     };

//     const handleCardClick = (interview) => {
//         setSelectedInterview(interview);
//         setShowCard(true);
//     };

//     const handleCloseCard = () => {
//         setShowCard(false);
//         setSelectedInterview(null);
//     };

//     const renderInterviews = (interviews) => {
//         return (
//             <tbody>
//                 {interviews.map(interview => (
//                     <tr key={interview.id}>
//                         <td onClick={() => handleCardClick(interview)}>{interview.candidateName}</td>
//                         <td>
//                             {interview.remarksAdded ? (
//                                 <button
//                                     onClick={() => handleViewResult(interview)}
//                                     className="btn btn-secondary ml-2"
//                                 >
//                                     View Remarks
//                                 </button>
//                             ) : (
//                                 "No Remarks"
//                             )}
//                         </td>
//                         <td>
//                             <button
//                                 onClick={() => handleResult(interview)}
//                                 className="btn btn-primary"
//                             >
//                                 Add Remark
//                             </button>
//                         </td>
//                     </tr>
//                 ))}
//             </tbody>
//         );
//     };

//     return (
//         <div className="user-page">
//             <div className="container">
//                 <h2>Scheduled Interviews</h2>
//                 {/* <h3>Response 1</h3> */}
//                 {response1.length === 0 ? (
//                     <p>No scheduled interviews yet.</p>
//                 ) : (
//                     <table className="table">
//                         <thead>
//                             <tr>
//                                 <th>Candidate Name</th>
//                                 <th>Remarks</th>
//                                 <th>Action</th>
//                             </tr>
//                         </thead>
//                         {renderInterviews(response1)}
//                     </table>
//                 )}

//                 {/* <h3>Response 2</h3> */}
//                 {response2.length === 0 ? (
//                     <p>No scheduled interviews yet.</p>
//                 ) : (
//                     <table className="table">
//                         <thead>
//                             <tr>
//                                 <th>Candidate Name</th>
//                                 <th>Remarks</th>
//                                 <th>Action</th>
//                             </tr>
//                         </thead>
//                         {renderInterviews(response2)}
//                     </table>
//                 )}

//                 {selectedInterview && (
//                     <Modal show={showModal} onHide={handleCloseModal}>
//                         <Modal.Header closeButton>
//                             <Modal.Title>Add Remark for {selectedInterview.candidateName}</Modal.Title>
//                         </Modal.Header>
//                         <Modal.Body>
//                             <input
//                                 type="text"
//                                 value={interviewerName}
//                                 onChange={(e) => setInterviewerName(e.target.value)}
//                                 className="form-control mb-3"
//                             />
//                             <textarea
//                                 value={newRemark}
//                                 onChange={(e) => setNewRemark(e.target.value)}
//                                 placeholder="Remark"
//                                 className="form-control mb-3"
//                             />
//                             <button onClick={handleAddRemark} className="btn btn-primary">
//                                 Add Remark
//                             </button>
//                         </Modal.Body>
//                         <Modal.Footer>
//                             <button className="btn btn-secondary" onClick={handleCloseModal}>
//                                 Close
//                             </button>
//                         </Modal.Footer>
//                     </Modal>
//                 )}

//                 {selectedInterview && (
//                     <Modal show={showResultModal} onHide={handleCloseResultModal}>
//                         <Modal.Header closeButton>
//                             <Modal.Title>My Interview Remarks for {selectedInterview.candidateName}</Modal.Title>
//                         </Modal.Header>
//                         <Modal.Body>
//                             <p><strong>My Remarks:</strong></p>
//                             {remarks.map((remark, index) => (
//                                 <div key={index}>
//                                     <p><strong>{remark.interviewerName}:</strong> {remark.remark}</p>
//                                 </div>
//                             ))}
//                         </Modal.Body>
//                         <Modal.Footer>
//                             <button className="btn btn-secondary" onClick={handleCloseResultModal}>
//                                 Close
//                             </button>
//                             <button
//                                 className="btn btn-primary"
//                                 onClick={() => {
//                                     setShowModal(true);
//                                     setShowResultModal(false);
//                                 }}
//                             >
//                                 Add Another Remark
//                             </button>
//                         </Modal.Footer>
//                     </Modal>
//                 )}

//                 {showCard && selectedInterview && (
//                     <Card className="mt-4">
//                         <Card.Body>
//                             <Card.Title>{selectedInterview.candidateName}</Card.Title>
//                             <Card.Subtitle className="mb-2 text-muted">{selectedInterview.appliedPosition}</Card.Subtitle>
//                             <button className="btn btn-secondary" onClick={handleCloseCard}>
//                                 Close
//                             </button>
//                         </Card.Body>
//                     </Card>
//                 )}
//             </div>
//         </div>
//     );
// };

// export default ScheduledInterview;




// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { Modal, Card } from 'react-bootstrap';
// import './UserPage.css';

// const ScheduledInterview = ({ userEmail, userType }) => {
//     const [scheduledInterviews, setScheduledInterviews] = useState([]);
//     const [showModal, setShowModal] = useState(false);
//     const [selectedInterview, setSelectedInterview] = useState(null);
//     const [remarks, setRemarks] = useState([]);
//     const [newRemark, setNewRemark] = useState('');
//     const [interviewerName, setInterviewerName] = useState('');
//     const [showResultModal, setShowResultModal] = useState(false);
//     const [showCard, setShowCard] = useState(false);

//     useEffect(() => {
//         if (userEmail) {
//             fetchScheduledInterviews(userEmail);
//         }
//     }, [userEmail]);

//     const fetchScheduledInterviews = async (email) => {
//         try {
//             const response1 = await axios.get(`http://localhost:8080/api/interviewschedules/interviewer/${email}`);
//             const response2 = await axios.get(`http://localhost:8080/api/interviewschedules/interviewer2/${email}`);

//             const mergedInterviews = [...response1.data, ...response2.data];

//             const savedState = JSON.parse(localStorage.getItem('remarksAddedState')) || [];
//             const updatedInterviews = mergedInterviews.map(interview => {
//                 const savedInterview = savedState.find(saved => saved.id === interview.id);
//                 return {
//                     ...interview,
//                     remarksAdded: savedInterview ? savedInterview.remarksAdded : false
//                 };
//             });

//             setScheduledInterviews(updatedInterviews);
//         } catch (error) {
//             console.error('Error fetching scheduled interviews:', error);
//         }
//     };

//     useEffect(() => {
//         if (scheduledInterviews.length > 0) {
//             localStorage.setItem('remarksAddedState', JSON.stringify(
//                 scheduledInterviews.map(interview => ({
//                     id: interview.id,
//                     remarksAdded: interview.remarksAdded || false
//                 }))
//             ));
//         }
//     }, [scheduledInterviews]);

//     const handleResult = (interview) => {
//         setSelectedInterview(interview);
//         setShowModal(true);
//     };

//     const handleCloseModal = () => {
//         setShowModal(false);
//         setSelectedInterview(null);
//     };

//     const handleViewResult = async (interview) => {
//         setSelectedInterview(interview);
//         await fetchRemarks(interview.id);
//         setShowResultModal(true);
//     };

//     const fetchRemarks = async (interviewId) => {
//         try {
//             const response = await axios.get(`http://localhost:8080/api/interview-remarks/interview/${interviewId}/interviewer/${userEmail}`);
//             setRemarks(response.data);
//         } catch (error) {
//             console.error('Error fetching remarks:', error);
//         }
//     };

//     const handleAddRemark = async () => {
//         if (newRemark.trim() === '' || interviewerName.trim() === '') return;
//         try {
//             const response = await axios.post('http://localhost:8080/api/interview-remarks', {
//                 candidate: { id: selectedInterview.candidateId },
//                 interview: { id: selectedInterview.id },
//                 interviewerName,
//                 interviewerEmail: userEmail,
//                 remark: newRemark,
//                 timestamp: new Date().toISOString()
//             });
//             setRemarks([...remarks, response.data]);
//             setNewRemark('');
//             setInterviewerName('');

//             const updatedInterviews = scheduledInterviews.map(interview =>
//                 interview.id === selectedInterview.id ? { ...interview, remarksAdded: true } : interview
//             );
//             setScheduledInterviews(updatedInterviews);

//             // Update interview status to "Interview Done"
//             await axios.put(`http://localhost:8080/api/interviewschedules/${selectedInterview.id}`, {
//                 ...selectedInterview,
//                 status: "Interview Done"
//             });

//         } catch (error) {
//             console.error('Error adding remark:', error);
//         }
//     };

//     const handleCloseResultModal = () => {
//         setShowResultModal(false);
//         setSelectedInterview(null);
//         setRemarks([]);
//     };

//     const handleCardClick = (interview) => {
//         setSelectedInterview(interview);
//         setShowCard(true);
//     };

//     const handleCloseCard = () => {
//         setShowCard(false);
//         setSelectedInterview(null);
//     };

//     return (
//         <div className="user-page">
//             <div className="container">
//                 <h2>Scheduled Interviews</h2>
//                 {scheduledInterviews.length === 0 ? (
//                     <p>No scheduled interviews yet.</p>
//                 ) : (
//                     <table className="table">
//                         <thead>
//                             <tr>
//                                 <th>Candidate Name</th>
//                                 <th>Remarks</th>
//                                 <th>Action</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {scheduledInterviews.map(interview => (
//                                 <tr key={interview.id}>
//                                     <td onClick={() => handleCardClick(interview)}>{interview.candidateName}</td>
//                                     <td>
//                                         {interview.remarksAdded ? (
//                                             <button
//                                                 onClick={() => handleViewResult(interview)}
//                                                 className="btn btn-secondary ml-2"
//                                             >
//                                                 View Remarks
//                                             </button>
//                                         ) : (
//                                             "No Remarks"
//                                         )}
//                                     </td>
//                                     <td>
//                                         <button
//                                             onClick={() => handleResult(interview)}
//                                             className="btn btn-primary"
//                                         >
//                                             Add Remark
//                                         </button>
//                                     </td>
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 )}

//                 {selectedInterview && (
//                     <Modal show={showModal} onHide={handleCloseModal}>
//                         <Modal.Header closeButton>
//                             <Modal.Title>Add Remark for {selectedInterview.candidateName}</Modal.Title>
//                         </Modal.Header>
//                         <Modal.Body>
//                             <input
//                                 type="text"
//                                 value={interviewerName}
//                                 onChange={(e) => setInterviewerName(e.target.value)}
//                                 className="form-control mb-3"
//                             />
//                             <textarea
//                                 value={newRemark}
//                                 onChange={(e) => setNewRemark(e.target.value)}
//                                 placeholder="Remark"
//                                 className="form-control mb-3"
//                             />
//                             <button onClick={handleAddRemark} className="btn btn-primary">
//                                 Add Remark
//                             </button>
//                         </Modal.Body>
//                         <Modal.Footer>
//                             <button className="btn btn-secondary" onClick={handleCloseModal}>
//                                 Close
//                             </button>
//                         </Modal.Footer>
//                     </Modal>
//                 )}

//                 {selectedInterview && (
//                     <Modal show={showResultModal} onHide={handleCloseResultModal}>
//                         <Modal.Header closeButton>
//                             <Modal.Title>My Interview Remarks for {selectedInterview.candidateName}</Modal.Title>
//                         </Modal.Header>
//                         <Modal.Body>
//                             <p><strong>My Remarks:</strong></p>
//                             {remarks.map((remark, index) => (
//                                 <div key={index}>
//                                     <p><strong>{remark.interviewerName}:</strong> {remark.remark}</p>
//                                 </div>
//                             ))}
//                         </Modal.Body>
//                         <Modal.Footer>
//                             <button className="btn btn-secondary" onClick={handleCloseResultModal}>
//                                 Close
//                             </button>
//                             <button
//                                 className="btn btn-primary"
//                                 onClick={() => {
//                                     setShowModal(true);
//                                     setShowResultModal(false);
//                                 }}
//                             >
//                                 Add Another Remark
//                             </button>
//                         </Modal.Footer>
//                     </Modal>
//                 )}

//                 {showCard && selectedInterview && (
//                     <Card className="mt-4">
//                         <Card.Body>
//                             <Card.Title>{selectedInterview.candidateName}</Card.Title>
//                             <Card.Subtitle className="mb-2 text-muted">{selectedInterview.appliedPosition}</Card.Subtitle>
//                             <button className="btn btn-secondary" onClick={handleCloseCard}>
//                                 Close
//                             </button>
//                         </Card.Body>
//                     </Card>
//                 )}
//             </div>
//         </div>
//     );
// };

// export default ScheduledInterview;


///////////////////////////////////localstorage

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Modal, Card } from 'react-bootstrap';
import './UserPage.css';

const ScheduledInterview = ({ userEmail, userType }) => {
    const [scheduledInterviews, setScheduledInterviews] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [selectedInterview, setSelectedInterview] = useState(null);
    const [remarks, setRemarks] = useState([]);
    const [newRemark, setNewRemark] = useState('');
    const [interviewerName, setInterviewerName] = useState('');
    const [showResultModal, setShowResultModal] = useState(false);
    const [showCard, setShowCard] = useState(false);

    useEffect(() => {
        if (userEmail) {
            fetchScheduledInterviews(userEmail);
        }
    }, [userEmail]);

    const fetchScheduledInterviews = async (email) => {
        try {
            const response1 = await axios.get(`http://localhost:8080/api/interviewschedules/interviewer/${email}`);
            const response2 = await axios.get(`http://localhost:8080/api/interviewschedules/interviewer2/${email}`);

            const mergedInterviews = [...response1.data, ...response2.data];

            const savedState = JSON.parse(localStorage.getItem('remarksAddedState')) || [];
            const updatedInterviews = mergedInterviews.map(interview => {
                const savedInterview = savedState.find(saved => saved.id === interview.id);
                return {
                    ...interview,
                    remarksAdded: savedInterview ? savedInterview.remarksAdded : false
                };
            });

            setScheduledInterviews(updatedInterviews);
        } catch (error) {
            console.error('Error fetching scheduled interviews:', error);
        }
    };

    useEffect(() => {
        if (scheduledInterviews.length > 0) {
            localStorage.setItem('remarksAddedState', JSON.stringify(
                scheduledInterviews.map(interview => ({
                    id: interview.id,
                    remarksAdded: interview.remarksAdded || false
                }))
            ));
        }
    }, [scheduledInterviews]);

    const handleResult = (interview) => {
        setSelectedInterview(interview);
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setSelectedInterview(null);
    };

    const handleViewResult = async (interview) => {
        setSelectedInterview(interview);
        await fetchRemarks(interview.id);
        setShowResultModal(true);
    };

    const fetchRemarks = async (interviewId) => {
        try {
            const savedRemarks = JSON.parse(localStorage.getItem(`remarks-${interviewId}`)) || [];
            setRemarks(savedRemarks);
        } catch (error) {
            console.error('Error fetching remarks:', error);
        }
    };

    const handleAddRemark = async () => {
        if (newRemark.trim() === '' || interviewerName.trim() === '') return;
        try {
            const newRemarkData = {
                candidate: { id: selectedInterview.candidateId },
                interview: { id: selectedInterview.id },
                interviewerName,
                interviewerEmail: userEmail,
                remark: newRemark,
                timestamp: new Date().toISOString()
            };
            const response = await axios.post('http://localhost:8080/api/interview-remarks', newRemarkData);
            
            const updatedRemarks = [...remarks, response.data];
            setRemarks(updatedRemarks);
            localStorage.setItem(`remarks-${selectedInterview.id}`, JSON.stringify(updatedRemarks));
            setNewRemark('');
            setInterviewerName('');

            const updatedInterviews = scheduledInterviews.map(interview =>
                interview.id === selectedInterview.id ? { ...interview, remarksAdded: true } : interview
            );
            setScheduledInterviews(updatedInterviews);

            // Update interview status to "Interview Done"
            await axios.put(`http://localhost:8080/api/interviewschedules/${selectedInterview.id}`, {
                ...selectedInterview,
                status: "Interview Done"
            });

        } catch (error) {
            console.error('Error adding remark:', error);
        }
    };

    const handleCloseResultModal = () => {
        setShowResultModal(false);
        setSelectedInterview(null);
        setRemarks([]);
    };

    const handleCardClick = (interview) => {
        setSelectedInterview(interview);
        setShowCard(true);
    };

    const handleCloseCard = () => {
        setShowCard(false);
        setSelectedInterview(null);
    };

    return (
        <div className="user-page">
            <div className="container">
                <h2>Scheduled Interviews</h2>
                {scheduledInterviews.length === 0 ? (
                    <p>No scheduled interviews yet.</p>
                ) : (
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Candidate Name</th>
                                <th>Remarks</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {scheduledInterviews.map(interview => (
                                <tr key={interview.id}>
                                    <td onClick={() => handleCardClick(interview)}>{interview.candidateName}</td>
                                    <td>
                                        {interview.remarksAdded ? (
                                            <button
                                                onClick={() => handleViewResult(interview)}
                                                className="btn btn-secondary ml-2"
                                            >
                                                View Remarks
                                            </button>
                                        ) : (
                                            "No Remarks"
                                        )}
                                    </td>
                                    <td>
                                        <button
                                            onClick={() => handleResult(interview)}
                                            className="btn btn-primary"
                                        >
                                            Add Remark
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}

                {selectedInterview && (
                    <Modal show={showModal} onHide={handleCloseModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Add Remark for {selectedInterview.candidateName}</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <input
                                type="text"
                                value={interviewerName}
                                onChange={(e) => setInterviewerName(e.target.value)}
                                className="form-control mb-3"
                            />
                            <textarea
                                value={newRemark}
                                onChange={(e) => setNewRemark(e.target.value)}
                                placeholder="Remark"
                                className="form-control mb-3"
                            />
                            <button onClick={handleAddRemark} className="btn btn-primary">
                                Add Remark
                            </button>
                        </Modal.Body>
                        <Modal.Footer>
                            <button className="btn btn-secondary" onClick={handleCloseModal}>
                                Close
                            </button>
                        </Modal.Footer>
                    </Modal>
                )}

                {selectedInterview && (
                    <Modal show={showResultModal} onHide={handleCloseResultModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>My Interview Remarks for {selectedInterview.candidateName}</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <p><strong>My Remarks:</strong></p>
                            {remarks.map((remark, index) => (
                                <div key={index}>
                                    <p><strong>{remark.interviewerName}:</strong> {remark.remark}</p>
                                </div>
                            ))}
                        </Modal.Body>
                        <Modal.Footer>
                            <button className="btn btn-secondary" onClick={handleCloseResultModal}>
                                Close
                            </button>
                            <button
                                className="btn btn-primary"
                                onClick={() => {
                                    setShowModal(true);
                                    setShowResultModal(false);
                                }}
                            >
                                Add Another Remark
                            </button>
                        </Modal.Footer>
                    </Modal>
                )}

                {showCard && selectedInterview && (
                    <Card className="mt-4">
                        <Card.Body>
                            <Card.Title>{selectedInterview.candidateName}</Card.Title>
                            <Card.Subtitle className="mb-2 text-muted">{selectedInterview.appliedPosition}</Card.Subtitle>
                            <button className="btn btn-secondary" onClick={handleCloseCard}>
                                Close
                            </button>
                        </Card.Body>
                    </Card>
                )}
            </div>
        </div>
    );
};

export default ScheduledInterview;
