// src/components/CandidateList.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import InterviewDetails from './InterviewDetails';

const CandidateList = () => {
    const [candidates, setCandidates] = useState([]);

    useEffect(() => {
        const fetchCandidates = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/candidates'); // Update the URL as per your backend
                setCandidates(response.data);
            } catch (error) {
                console.error('Error fetching candidates:', error);
            }
        };

        fetchCandidates();
    }, []);

    return (
        <div>
            <h1>Candidate List</h1>
            <ul>
                {candidates.map(candidate => (
                    <li key={candidate.id}>
                        {candidate.name} - {candidate.email}
                        <InterviewDetails interview={candidate.interview} />
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default CandidateList;
