




// import React, { useState } from "react";
// import { Modal, Button, Form } from "react-bootstrap";

// const AddJobModal = ({ show, handleClose, handleAddJob }) => {
//   const [jobDescription, setJobDescription] = useState("");
//   const [newJob, setNewJob] = useState({
//     jobName: "",
//     experience: "",
//     neededSkills: "",
//     jobDescription: "",
//     closingDate: "",
//     openings: "",
//     responsibility:"",
//     status: "Open",
//   });

//   const handleJobDescriptionChange = (e) => {
//     const description = e.target.value;
//     setJobDescription(description);

//     // Automatically fill other fields based on job description
//     const jobDetails = generateJobDetailsFromDescription(description);
//     setNewJob({ ...newJob, jobDescription: description, ...jobDetails });
//   };

//   const generateJobDetailsFromDescription = (description) => {
//     // This is a simple example. In a real application, you might use a more sophisticated method
//     // to extract job details from the description, such as using NLP techniques or predefined keywords.
//     return {
//       jobName: "",
//       experience: "",
//       neededSkills: "",
//       closingDate: "",
//       openings: "",
//     };
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     handleAddJob(newJob);
//   };

//   return (
//     <Modal show={show} onHide={handleClose}>
//       <Modal.Header closeButton>
//         <Modal.Title>Add Job</Modal.Title>
//       </Modal.Header>
//       <Modal.Body>
//         <Form onSubmit={handleSubmit}>
//           <Form.Group controlId="formJobDescription">
//             <Form.Label>Job Description</Form.Label>
//             <Form.Control
//               as="textarea"
//               rows={3}
//               value={jobDescription}
//               onChange={handleJobDescriptionChange}
//               placeholder="Enter job description"
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formJobName">
//             <Form.Label>Job Name</Form.Label>
//             <Form.Control
//               type="text"
//               value={newJob.jobName}
//               onChange={(e) => setNewJob({ ...newJob, jobName: e.target.value })}
//               placeholder="Enter job name"
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formExperience">
//             <Form.Label>Experience</Form.Label>
//             <Form.Control
//               type="text"
//               value={newJob.experience}
//               onChange={(e) => setNewJob({ ...newJob, experience: e.target.value })}
//               placeholder="Enter experience"
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formNeededSkills">
//             <Form.Label>Skills Required</Form.Label>
//             <Form.Control
//               type="text"
//               value={newJob.neededSkills}
//               onChange={(e) => setNewJob({ ...newJob, neededSkills: e.target.value })}
//               placeholder="Enter skills required"
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formClosingDate">
//             <Form.Label>Closing Date</Form.Label>
//             <Form.Control
//               type="date"
//               value={newJob.closingDate}
//               onChange={(e) => setNewJob({ ...newJob, closingDate: e.target.value })}
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formOpenings">
//             <Form.Label>Openings</Form.Label>
//             <Form.Control
//               type="number"
//               value={newJob.openings}
//               onChange={(e) => setNewJob({ ...newJob, openings: e.target.value })}
//               placeholder="Enter number of openings"
//               required
//             />
//           </Form.Group>

//           <Form.Group controlId="formNeededSkills">
//             <Form.Label>responsibility</Form.Label>
//             <Form.Control
//               type="text"
//               value={newJob.responsibility}
//               onChange={(e) => setNewJob({ ...newJob, responsibility: e.target.value })}
//               placeholder="Enter skills required"
//               required
//             />
//           </Form.Group>
//           <Button variant="primary" type="submit">
//             Add Job
//           </Button>
//         </Form>
//       </Modal.Body>
//     </Modal>
//   );
// };

// export default AddJobModal;




// import React, { useState } from "react";
// import { Modal, Button, Form } from "react-bootstrap";

// const AddJobModal = ({ show, handleClose, handleAddJob }) => {
//   const [jobDescription, setJobDescription] = useState("");
//   const [newJob, setNewJob] = useState({
//     jobName: "",
//     experience: "",
//     neededSkills: "",
//     jobDescription: "",
//     closingDate: "",
//     openings: "",
//     responsibility:"",
//     status: "Open",
//   });

//   const handleJobDescriptionChange = (e) => {
//     const description = e.target.value;
//     setJobDescription(description);

//     // Automatically fill other fields based on job description
//     const jobDetails = generateJobDetailsFromDescription(description);
//     setNewJob({ ...newJob, jobDescription: description, ...jobDetails });
//   };

//   const generateJobDetailsFromDescription = (description) => {
//     // This is a simple example. In a real application, you might use a more sophisticated method
//     // to extract job details from the description, such as using NLP techniques or predefined keywords.
//     return {
//       jobName: "",
//       experience: "",
//       neededSkills: "",
//       closingDate: "",
//       openings: "",
//     };
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     handleAddJob(newJob);
//   };

//   return (
//     <Modal show={show} onHide={handleClose} fullscreen={true}>
//       <Modal.Header closeButton>
//         <Modal.Title>Add Job</Modal.Title>
//       </Modal.Header>
//       <Modal.Body>
//         <Form onSubmit={handleSubmit}>
//           <Form.Group controlId="formJobDescription">
//             <Form.Label>Job Description</Form.Label>
//             <Form.Control
//               as="textarea"
//               rows={3}
//               value={jobDescription}
//               onChange={handleJobDescriptionChange}
//               placeholder="Enter job description"
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formJobName">
//             <Form.Label>Job Name</Form.Label>
//             <Form.Control
//               type="text"
//               value={newJob.jobName}
//               onChange={(e) => setNewJob({ ...newJob, jobName: e.target.value })}
//               placeholder="Enter job name"
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formExperience">
//             <Form.Label>Experience</Form.Label>
//             <Form.Control
//               type="text"
//               value={newJob.experience}
//               onChange={(e) => setNewJob({ ...newJob, experience: e.target.value })}
//               placeholder="Enter experience"
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formNeededSkills">
//             <Form.Label>Skills Required</Form.Label>
//             <Form.Control
//               type="text"
//               value={newJob.neededSkills}
//               onChange={(e) => setNewJob({ ...newJob, neededSkills: e.target.value })}
//               placeholder="Enter skills required"
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formClosingDate">
//             <Form.Label>Closing Date</Form.Label>
//             <Form.Control
//               type="date"
//               value={newJob.closingDate}
//               onChange={(e) => setNewJob({ ...newJob, closingDate: e.target.value })}
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formOpenings">
//             <Form.Label>Openings</Form.Label>
//             <Form.Control
//               type="number"
//               value={newJob.openings}
//               onChange={(e) => setNewJob({ ...newJob, openings: e.target.value })}
//               placeholder="Enter number of openings"
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="formResponsibility">
//             <Form.Label>Responsibility</Form.Label>
//             <Form.Control
//               type="text"
//               value={newJob.responsibility}
//               onChange={(e) => setNewJob({ ...newJob, responsibility: e.target.value })}
//               placeholder="Enter responsibilities"
//               required
//             />
//           </Form.Group>
//           <Button variant="primary" type="submit">
//             Add Job
//           </Button>
//         </Form>
//       </Modal.Body>
//     </Modal>
//   );
// };

// export default AddJobModal;

import React, { useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";

const AddJobModal = ({ show, handleClose, handleAddJob }) => {
  const [jobDescription, setJobDescription] = useState("");
  const [newJob, setNewJob] = useState({
    jobName: "",
    experience: "",
    neededSkills: "",
    jobDescription: "",
    closingDate: "",
    openings: "",
    responsibility: "",
    status: "Open",
  });

  const handleJobDescriptionChange = (e) => {
    const description = e.target.value;
    setJobDescription(description);

    const jobDetails = generateJobDetailsFromDescription(description);
    setNewJob({ ...newJob, jobDescription: description, ...jobDetails });
  };

  const generateJobDetailsFromDescription = (description) => {
    return {
      jobName: "",
      experience: "",
      neededSkills: "",
      closingDate: "",
      openings: "",
    };
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleAddJob(newJob);
  };

  return (
    <Modal show={show} onHide={handleClose} size="lg">
      <Modal.Header closeButton>
        <Modal.Title>Add Job</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="formJobDescription">
            <Form.Label>Job Description</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              value={jobDescription}
              onChange={handleJobDescriptionChange}
              placeholder="Enter job description"
              required
            />
          </Form.Group>
          <Form.Group controlId="formJobName">
            <Form.Label>Job Name</Form.Label>
            <Form.Control
              type="text"
              value={newJob.jobName}
              onChange={(e) => setNewJob({ ...newJob, jobName: e.target.value })}
              placeholder="Enter job name"
              required
            />
          </Form.Group>
          <Form.Group controlId="formExperience">
            <Form.Label>Experience</Form.Label>
            <Form.Control
              type="text"
              value={newJob.experience}
              onChange={(e) => setNewJob({ ...newJob, experience: e.target.value })}
              placeholder="Enter experience"
              required
            />
          </Form.Group>
          <Form.Group controlId="formNeededSkills">
            <Form.Label>Skills Required</Form.Label>
            <Form.Control
              type="text"
              value={newJob.neededSkills}
              onChange={(e) => setNewJob({ ...newJob, neededSkills: e.target.value })}
              placeholder="Enter skills required"
              required
            />
          </Form.Group>
          <Form.Group controlId="formClosingDate">
            <Form.Label>Closing Date</Form.Label>
            <Form.Control
              type="date"
              value={newJob.closingDate}
              onChange={(e) => setNewJob({ ...newJob, closingDate: e.target.value })}
              required
            />
          </Form.Group>
          <Form.Group controlId="formOpenings">
            <Form.Label>Openings</Form.Label>
            <Form.Control
              type="number"
              value={newJob.openings}
              onChange={(e) => setNewJob({ ...newJob, openings: e.target.value })}
              placeholder="Enter number of openings"
              required
            />
          </Form.Group>
          <Form.Group controlId="formResponsibility">
            <Form.Label>Responsibility</Form.Label>
            <Form.Control
              type="text"
              value={newJob.responsibility}
              onChange={(e) => setNewJob({ ...newJob, responsibility: e.target.value })}
              placeholder="Enter responsibilities"
              required
            />
          </Form.Group>
          <Button variant="primary" type="submit">
            Add Job
          </Button>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default AddJobModal;
