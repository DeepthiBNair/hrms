





// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { toast, ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import './UserPage.css';
// import InterviewScheduleModal from './InterviewScheduleModal';
// import { Card, Button, Modal } from 'react-bootstrap';
// import { FaEye, FaFileAlt, FaCalendarAlt } from 'react-icons/fa';

// function ListAllCandidate() {
//   const [registrations, setRegistrations] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedCandidate, setSelectedCandidate] = useState(null);
//   const [viewingResume, setViewingResume] = useState(false);
//   const [detailsModal, setDetailsModal] = useState(false);
//   const [remarks, setRemarks] = useState([]);

//   useEffect(() => {
//     async function fetchRegistrations() {
//       try {
//         const response = await axios.get("http://localhost:8080/api/candidates");
//         setRegistrations(response.data);
//       } catch (error) {
//         console.error("Error fetching registrations:", error);
//       }
//     }

//     fetchRegistrations();
//   }, []);

//   const updateCandidateList = (updatedCandidate) => {
//     setRegistrations(prevRegistrations =>
//       prevRegistrations.map(candidate =>
//         candidate.id === updatedCandidate.id ? updatedCandidate : candidate
//       )
//     );
//   };

//   const handleShowModal = (candidate) => {
//     setSelectedCandidate(candidate);
//     setShowModal(true);
//   };

//   const handleCloseModal = () => {
//     setSelectedCandidate(null);
//     setShowModal(false);
//   };

//   const handleViewResume = (candidateId) => {
//     setViewingResume(true);
//     setSelectedCandidate(registrations.find(candidate => candidate.id === candidateId));
//   };

//   const handleViewDetails = (candidate) => {
//     setSelectedCandidate(candidate);
//     fetchRemarks(candidate.id);  // Fetch remarks when viewing details
//     setDetailsModal(true);
//   };

//   const handleCloseDetailsModal = () => {
//     setSelectedCandidate(null);
//     setDetailsModal(false);
//   };

//   const fetchRemarks = async (candidateId) => {
//     try {
//       const response = await axios.get(`http://localhost:8080/api/interview-remarks/candidate/${candidateId}`);
//       setRemarks(response.data);
//     } catch (error) {
//       console.error('Error fetching remarks:', error);
//     }
//   };

//   const hireCandidate = async () => {
//     try {
//       const updatedCandidate = { ...selectedCandidate, result: "Hired" };
//       await axios.put(`http://localhost:8080/api/candidates/${selectedCandidate.id}`, updatedCandidate);

//       updateCandidateList(updatedCandidate); // Update the list after hiring
//       setSelectedCandidate(updatedCandidate); // Update selected candidate to reflect the change

//       toast.success(`Successfully hired ${selectedCandidate.name}`);
//     } catch (error) {
//       console.error('Error hiring candidate:', error);
//       toast.error('Failed to hire candidate. Please try again.');
//     }
//   };

//   const rejectCandidate = async () => {
//     try {
//       const updatedCandidate = { ...selectedCandidate, result: "Rejected" };
//       await axios.put(`http://localhost:8080/api/candidates/${selectedCandidate.id}/reject`);

//       updateCandidateList(updatedCandidate); // Update the list after rejecting
//       setSelectedCandidate(updatedCandidate); // Update selected candidate to reflect the change

//       toast.success(`Successfully rejected ${selectedCandidate.name}`);
//     } catch (error) {
//       console.error('Error rejecting candidate:', error);
//       toast.error('Failed to reject candidate. Please try again.');
//     }
//   };

//   return (
//     <div className="user-page">
//       <ToastContainer position="top-center" />
//       <h2 className="text-center">List of Candidates</h2>
//       <div className="card-container">
//         {registrations.map((candidate) => (
//           <Card key={candidate.id} className="candidate-card">
//             <Card.Body>
//               <Card.Title>{candidate.name}</Card.Title>
//               <Card.Subtitle className="mb-2 text-muted">{candidate.email}</Card.Subtitle>
//               <Card.Text>
//                 Phone: {candidate.phone}<br />
//                 Designation: {candidate.designation}<br />
//                 Qualification: {candidate.qualification}
//               </Card.Text>
//               <Button variant="secondary" onClick={() => handleViewResume(candidate.id)}>
//                 <FaFileAlt /> Resume
//               </Button>
//               <Button variant="info" className="ml-2" onClick={() => handleViewDetails(candidate)}>
//                 <FaEye /> Details
//               </Button>
//               {candidate.status === "Scheduled" ? (
//                 <Button variant="success" disabled className="ml-2">
//                   <FaCalendarAlt /> Scheduled
//                 </Button>
//               ) : (
//                 <Button
//                   variant="secondary"
//                   className="ml-2 mt-2"
//                   onClick={() => handleShowModal(candidate)}
//                 >
//                   <FaCalendarAlt /> Schedule
//                 </Button>
//               )}
//             </Card.Body>
//           </Card>
//         ))}
//       </div>
//       {selectedCandidate && (
//         <InterviewScheduleModal
//           show={showModal}
//           handleClose={handleCloseModal}
//           candidate={selectedCandidate}
//           updateCandidateList={updateCandidateList}
//         />
//       )}
//       {viewingResume && selectedCandidate && (
//         <div className="modal" style={{ display: 'block', backgroundColor: 'rgba(0, 0, 0, 0.5)', position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 9999 }}>
//           <div className="modal-dialog modal-lg modal-dialog-centered" role="document">
//             <div className="modal-content">
//               <div className="modal-header">
//                 <h5 className="modal-title">{selectedCandidate.name}'s Resume</h5>
//                 <button type="button" className="close" onClick={() => setViewingResume(false)}>
//                   <span aria-hidden="true">&times;</span>
//                 </button>
//               </div>
//               <div className="modal-body">
//                 <embed
//                   src={`data:application/pdf;base64,${selectedCandidate.resume}`}
//                   type="application/pdf"
//                   width="100%"
//                   height="600px"
//                 />
//               </div>
//               <div className="modal-footer">
//                 <Button variant="secondary" onClick={() => setViewingResume(false)}>Close</Button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//       {selectedCandidate && (
//         <Modal show={detailsModal} onHide={handleCloseDetailsModal}>
//           <Modal.Header closeButton>
//             <Modal.Title>Interview Details of {selectedCandidate.name}</Modal.Title>
//           </Modal.Header>
//           <Modal.Body>
//             <p>Status: {selectedCandidate.status}</p>
//             <p><strong>Remarks:</strong></p>
//             {remarks.length > 0 ? (
//               remarks.map((remark, index) => (
//                 <div key={index}>
//                   <p><strong>{remark.interviewerName}:</strong> {remark.remark}</p>
//                 </div>
//               ))
//             ) : (
//               <p>No remarks available.</p>
//             )}
//           </Modal.Body>
//           <Modal.Footer>
//             <Button variant="secondary" onClick={handleCloseDetailsModal}>Close</Button>
//             <Button
//               variant={selectedCandidate.result === "Hired" ? "success" : "secondary"}
//               onClick={hireCandidate}
//               disabled={selectedCandidate.result === "Hired"}
//             >
//               {selectedCandidate.result === "Hired" ? "Hired" : "Hire"}
//             </Button>
//             <Button
//               variant={selectedCandidate.result === "Rejected" ? "danger" : "secondary"}
//               onClick={rejectCandidate}
//               disabled={selectedCandidate.result === "Rejected"}
//             >
//               {selectedCandidate.result === "Rejected" ? "Rejected" : "Reject"}
//             </Button>
//           </Modal.Footer>
//         </Modal>
//       )}
//     </div>
//   );
// }

// export default ListAllCandidate;
















// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { toast, ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import './UserPage.css';
// import InterviewScheduleModal from './InterviewScheduleModal';
// import { Card, Button, Modal, Form } from 'react-bootstrap';
// import { FaEye, FaFileAlt, FaCalendarAlt } from 'react-icons/fa';

// function ListAllCandidate() {
//   const [registrations, setRegistrations] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedCandidate, setSelectedCandidate] = useState(null);
//   const [viewingResume, setViewingResume] = useState(false);
//   const [detailsModal, setDetailsModal] = useState(false);
//   const [remarks, setRemarks] = useState([]);
//   const [decision, setDecision] = useState(""); // State for the decision dropdown

//   useEffect(() => {
//     async function fetchRegistrations() {
//       try {
//         const response = await axios.get("http://localhost:8080/api/candidates");
//         setRegistrations(response.data);
//       } catch (error) {
//         console.error("Error fetching registrations:", error);
//       }
//     }

//     fetchRegistrations();
//   }, []);

//   const updateCandidateList = (updatedCandidate) => {
//     setRegistrations(prevRegistrations =>
//       prevRegistrations.map(candidate =>
//         candidate.id === updatedCandidate.id ? updatedCandidate : candidate
//       )
//     );
//   };

//   const handleShowModal = (candidate) => {
//     setSelectedCandidate(candidate);
//     setShowModal(true);
//   };

//   const handleCloseModal = () => {
//     setSelectedCandidate(null);
//     setShowModal(false);
//   };

//   const handleViewResume = (candidateId) => {
//     setViewingResume(true);
//     setSelectedCandidate(registrations.find(candidate => candidate.id === candidateId));
//   };

//   const handleViewDetails = (candidate) => {
//     setSelectedCandidate(candidate);
//     fetchRemarks(candidate.id);  // Fetch remarks when viewing details
//     setDetailsModal(true);
//   };

//   const handleCloseDetailsModal = () => {
//     setSelectedCandidate(null);
//     setDetailsModal(false);
//   };

//   const fetchRemarks = async (candidateId) => {
//     try {
//       const response = await axios.get(`http://localhost:8080/api/interview-remarks/candidate/${candidateId}`);
//       setRemarks(response.data);
      
//       if (response.data.length > 0) {
//         setSelectedCandidate(prevCandidate => ({
//           ...prevCandidate,
//           status: "Interview Done"
//         }));
//         updateCandidateList({
//           ...selectedCandidate,
//           status: "Interview Done"
//         });
//       }
//     } catch (error) {
//       console.error('Error fetching remarks:', error);
//     }
//   };

//   const updateDecision = async () => {
//     try {
//       const updatedCandidate = { ...selectedCandidate, result: decision };
//       await axios.put(`http://localhost:8080/api/candidates/${selectedCandidate.id}/decision`, updatedCandidate);

//       updateCandidateList(updatedCandidate); // Update the list after changing decision
//       setSelectedCandidate(updatedCandidate); // Update selected candidate to reflect the change

//       toast.success(`Successfully updated decision for ${selectedCandidate.name}`);
//     } catch (error) {
//       console.error('Error updating decision:', error);
//       toast.error('Failed to update decision. Please try again.');
//     }
//   };

//   return (
//     <div className="user-page">
//       <ToastContainer position="top-center" />
//       {/* <h2 className="text-center">List of Candidates</h2> */}
//       <div className="card-container">
//         {registrations.map((candidate) => (
//           <Card key={candidate.id} className="candidate-card">
//             <Card.Body>
//               <Card.Title>{candidate.name}</Card.Title>
//               <Card.Subtitle className="mb-2 text-muted">{candidate.email}</Card.Subtitle>
//               <Card.Text>
//                 Phone: {candidate.phone}<br />
//                 Designation: {candidate.designation}<br />
//                 Qualification: {candidate.qualification}
//                 {candidate.result && (
//                   <p><strong>{candidate.result}</strong></p>
//                 )}
//               </Card.Text>
//               <Button variant="secondary" onClick={() => handleViewResume(candidate.id)}>
//                 <FaFileAlt /> Resume
//               </Button>
//               <Button variant="info" className="ml-2" onClick={() => handleViewDetails(candidate)}>
//                 <FaEye /> Details
//               </Button>
//               {candidate.status === "Scheduled" ? (
//                 <Button variant="success" disabled className="ml-2">
//                   <FaCalendarAlt /> Scheduled
//                 </Button>
//               ) : candidate.status === "Interview Done" ? (
//                 <Button variant="success" disabled className="ml-2">
//                   <FaCalendarAlt /> Interview Done
//                 </Button>
//               ) : (
//                 <Button
//                   variant="secondary"
//                   className="ml-2 mt-2"
//                   onClick={() => handleShowModal(candidate)}
//                 >
//                   <FaCalendarAlt /> Schedule
//                 </Button>
//               )}
//             </Card.Body>
//           </Card>
//         ))}
//       </div>
//       {selectedCandidate && (
//         <InterviewScheduleModal
//           show={showModal}
//           handleClose={handleCloseModal}
//           candidate={selectedCandidate}
//           updateCandidateList={updateCandidateList}
//         />
//       )}
//       {viewingResume && selectedCandidate && (
//         <div className="modal" style={{ display: 'block', backgroundColor: 'rgba(0, 0, 0, 0.5)', position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 9999 }}>
//           <div className="modal-dialog modal-lg modal-dialog-centered" role="document">
//             <div className="modal-content">
//               <div className="modal-header">
//                 <h5 className="modal-title">{selectedCandidate.name}'s Resume</h5>
//                 <button type="button" className="close" onClick={() => setViewingResume(false)}>
//                   <span aria-hidden="true">&times;</span>
//                 </button>
//               </div>
//               <div className="modal-body">
//                 <embed
//                   src={`data:application/pdf;base64,${selectedCandidate.resume}`}
//                   type="application/pdf"
//                   width="100%"
//                   height="600px"
//                 />
//               </div>
//               <div className="modal-footer">
//                 <Button variant="secondary" onClick={() => setViewingResume(false)}>Close</Button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//       {selectedCandidate && (
//         <Modal show={detailsModal} onHide={handleCloseDetailsModal}>
//           <Modal.Header closeButton>
//             <Modal.Title>Interview Details of {selectedCandidate.name}</Modal.Title>
//           </Modal.Header>
//           <Modal.Body>
//             <p>Status: {selectedCandidate.status}</p>
//             <p><strong>Remarks:</strong></p>
//             {remarks.length > 0 ? (
//               remarks.map((remark, index) => (
//                 <div key={index}>
//                   <p><strong>{remark.interviewerName}:</strong> {remark.remark}</p>
//                 </div>
//               ))
//             ) : (
//               <p>No remarks available.</p>
//             )}
//             <Form.Group controlId="decisionSelect">
//               <Form.Label>Decision</Form.Label>
//               <Form.Control as="select" value={decision} onChange={(e) => setDecision(e.target.value)}>
//                 <option value="">Select Decision</option>
//                 <option value="HIRED">Hired</option>
//                 <option value="REJECTED">Rejected</option>
//                 <option value="WILL_USE_IN_FUTURE">Will Use in Future</option>
//                 <option value="SHORT_LISTED_BUT_HIGH_PACKAGE">Short Listed but High Package</option>
//               </Form.Control>
//             </Form.Group>
//           </Modal.Body>
//           <Modal.Footer>
//             <Button variant="secondary" onClick={handleCloseDetailsModal}>Close</Button>
//             <Button
//               variant="primary"
//               onClick={updateDecision}
//               disabled={!decision}
//             >
//               Update Decision
//             </Button>
//           </Modal.Footer>
//         </Modal>
//       )}
//     </div>
//   );
// }

// export default ListAllCandidate;







// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { toast, ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import './UserPage.css';
// import InterviewScheduleModal from './InterviewScheduleModal';
// import { Card, Button, Modal, Form } from 'react-bootstrap';
// import { FaEye, FaFileAlt, FaCalendarAlt } from 'react-icons/fa';

// function ListAllCandidate() {
//   const [registrations, setRegistrations] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedCandidate, setSelectedCandidate] = useState(null);
//   const [viewingResume, setViewingResume] = useState(false);
//   const [detailsModal, setDetailsModal] = useState(false);
//   const [remarks, setRemarks] = useState([]);
//   const [applicationStatus, setApplicationStatus] = useState('');
//   const [showAdditionalFields, setShowAdditionalFields] = useState(false);
//   const [offerLetter, setOfferLetter] = useState('');
//   const [packageOffered, setPackageOffered] = useState('');
//   const [joiningDate, setJoiningDate] = useState('');
//   const [payoutPossible, setPayoutPossible] = useState('');

//   useEffect(() => {
//     async function fetchRegistrations() {
//       try {
//         const response = await axios.get("http://localhost:8080/api/candidates");
//         setRegistrations(response.data);
//       } catch (error) {
//         console.error("Error fetching registrations:", error);
//       }
//     }

//     fetchRegistrations();
//   }, []);

//   const updateCandidateList = (updatedCandidate) => {
//     setRegistrations(prevRegistrations =>
//       prevRegistrations.map(candidate =>
//         candidate.id === updatedCandidate.id ? updatedCandidate : candidate
//       )
//     );
//   };

//   const handleShowModal = (candidate) => {
//     setSelectedCandidate(candidate);
//     setShowModal(true);
//   };

//   const handleCloseModal = () => {
//     setSelectedCandidate(null);
//     setShowModal(false);
//   };

//   const handleViewResume = (candidateId) => {
//     setViewingResume(true);
//     setSelectedCandidate(registrations.find(candidate => candidate.id === candidateId));
//   };

//   const handleViewDetails = (candidate) => {
//     setSelectedCandidate(candidate);
//     fetchRemarks(candidate.id);
//     setDetailsModal(true);
//   };

//   const handleCloseDetailsModal = () => {
//     setSelectedCandidate(null);
//     setDetailsModal(false);
//   };

//   const fetchRemarks = async (candidateId) => {
//     try {
//       const response = await axios.get(`http://localhost:8080/api/interview-remarks/candidate/${candidateId}`);
//       setRemarks(response.data);

//       if (response.data.length > 0) {
//         setSelectedCandidate(prevCandidate => ({
//           ...prevCandidate,
//           status: "Interview Done"
//         }));
//         updateCandidateList({
//           ...selectedCandidate,
//           status: "Interview Done"
//         });
//       }
//     } catch (error) {
//       console.error('Error fetching remarks:', error);
//     }
//   };

//   const handleStatusChange = (e) => {
//     const status = e.target.value;
//     setApplicationStatus(status);
//     setShowAdditionalFields(status === "shortlisted" || status === "shortlisted-high-package"||status==="reject");
//   };

//   const handleOfferLetterChange = (e) => {
//     setOfferLetter(e.target.value);
//   };

//   const handlePackageOfferedChange = (e) => {
//     setPackageOffered(e.target.value);
//   };

//   const handleJoiningDateChange = (e) => {
//     setJoiningDate(e.target.value);
//   };

//   const handlePayoutPossibleChange = (e) => {
//     setPayoutPossible(e.target.value);
//   };

//   const handleSubmit = async () => {
//     try {
//       let endpoint = "";
//       switch (applicationStatus) {
//         case "rejected":
//           endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/reject`;
//           break;
//         case "shortlisted":
//           endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/shortlist`;
//           break;
//         case "shortlisted-high-package":
//           endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/shortlist-high-package`;
//           break;
//         default:
//           console.error("Invalid application status selected");
//           return;
//       }

//       const response = await axios.put(endpoint, {
//         offerLetter: offerLetter,
//         packageOffered: packageOffered,
//         joiningDate: joiningDate,
//         payoutPossible: payoutPossible
//       });

//       const updatedCandidate = {
//         ...selectedCandidate,
//         status: applicationStatus
//       };

//       updateCandidateList(updatedCandidate);

//       toast.success('Candidate status updated successfully');
//       handleCloseDetailsModal();
//     } catch (error) {
//       console.error('Error updating candidate status:', error);
//       toast.error('Failed to update candidate status. Please try again.');
//     }
//   };

//   return (
//     <div className="user-page">
//       <ToastContainer position="top-center" />
//       <div className="card-container">
//         {registrations.map((candidate) => (
//           <Card key={candidate.id} className="candidate-card">
//             <Card.Body>
//               <Card.Title>{candidate.name}</Card.Title>
//               <Card.Subtitle className="mb-2 text-muted">{candidate.email}</Card.Subtitle>
//               <Card.Text>
//                 Phone: {candidate.phone}<br />
//                 Designation: {candidate.designation}<br />
//                 Qualification: {candidate.qualification}
//                 {candidate.status && (
//                   <p><strong>Status: {candidate.result}</strong></p>
//                 )}
//               </Card.Text>
//               <Button variant="secondary" onClick={() => handleViewResume(candidate.id)}>
//                 <FaFileAlt /> Resume
//               </Button>
//               <Button variant="info" className="ml-2" onClick={() => handleViewDetails(candidate)}>
//                 <FaEye /> Details
//               </Button>
//               {candidate.status === "Scheduled" ? (
//                 <Button variant="success" disabled className="ml-2">
//                   <FaCalendarAlt /> Interview Scheduled
//                 </Button>
//               ) : candidate.status === "Interview Done" ? (
//                 <Button variant="success" disabled className="ml-2">
//                   <FaCalendarAlt /> Interview Done
//                 </Button>
//               ) : (
//                 <Button
//                   variant="secondary"
//                   className="ml-2 mt-2"
//                   onClick={() => handleShowModal(candidate)}
//                 >
//                   <FaCalendarAlt /> Interview Schedule
//                 </Button>
//               )}
//             </Card.Body>
//           </Card>
//         ))}
//       </div>
//       {selectedCandidate && (
//         <InterviewScheduleModal
//           show={showModal}
//           handleClose={handleCloseModal}
//           candidate={selectedCandidate}
//           updateCandidateList={updateCandidateList}
//         />
//       )}
//       {viewingResume && selectedCandidate && (
//         <div className="modal" style={{ display: 'block', backgroundColor: 'rgba(0, 0, 0, 0.5)', position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 9999 }}>
//           <div className="modal-dialog modal-lg modal-dialog-centered" role="document">
//             <div className="modal-content">
//               <div className="modal-header">
//                 <h5 className="modal-title">{selectedCandidate.name}'s Resume</h5>
//                 <button type="button" className="close" onClick={() => setViewingResume(false)}>
//                   <span aria-hidden="true">&times;</span>
//                 </button>
//               </div>
//               <div className="modal-body">
//                 <embed
//                   src={`data:application/pdf;base64,${selectedCandidate.resume}`}
//                   type="application/pdf"
//                   width="100%"
//                   height="600px"
//                 />
//               </div>
//               <div className="modal-footer">
//                 <Button variant="secondary" onClick={() => setViewingResume(false)}>Close</Button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//       {selectedCandidate && (
//         <Modal show={detailsModal} onHide={handleCloseDetailsModal} size="lg">
//           <Modal.Header closeButton>
//             <Modal.Title>Interview Details of {selectedCandidate.name}</Modal.Title>
//           </Modal.Header>
//           <Modal.Body>
//             <p>Status: {selectedCandidate.status}</p>
//             <div className="form-group">
//               <label>Interview Details</label>
//               <table className="table">
//                 <thead>
//                   <tr>
//                     <th>Interviewer</th>
//                     <th>Remarks</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {remarks.length > 0 ? (
//                     remarks.map((remark, index) => (
//                       <tr key={index}>
//                         <td>{remark.interviewerName}</td>
//                         <td>{remark.remark}</td>
//                       </tr>
//                     ))
//                   ) : (
//                     <tr>
//                       <td colSpan="2">No remarks available</td>
//                     </tr>
//                   )}
//                 </tbody>
//               </table>
//             </div>
//             <div className="form-group">
//               <label>Application Status</label>
//               <select className="form-control" value={applicationStatus} onChange={handleStatusChange}>
//                 <option value="">Select status</option>
//                 <option value="shortlisted">Shortlisted</option>
//                 <option value="shortlisted-high-package">Shortlisted but High Package</option>
//                 <option value="rejected">Rejected</option>
//                 <option value="future-use">Will Use in Future</option>
//               </select>
//             </div>
//             {showAdditionalFields && (
//               <>
//                 <div className="form-group">
//                   <label>Offer Letter</label>
//                   <Form.Check
//                     type="radio"
//                     label="Shared"
//                     value="shared"
//                     checked={offerLetter === "shared"}
//                     onChange={handleOfferLetterChange}
//                   />
//                   <Form.Check
//                     type="radio"
//                     label="Accepted"
//                     value="accepted"
//                     checked={offerLetter === "accepted"}
//                     onChange={handleOfferLetterChange}
//                   />
//                   <Form.Check
//                     type="radio"
//                     label="Declined"
//                     value="declined"
//                     checked={offerLetter === "declined"}
//                     onChange={handleOfferLetterChange}
//                   />
//                 </div>
//                 <div className="form-group">
//   <label>Package Offered</label>
//   <input
//     type="text"
//     className="form-control"
//     value={packageOffered}
//     onChange={handlePackageOfferedChange}
//     placeholder="Enter package offered"
//   />
// </div>
//                 <div className="form-group">
//                   <label>Joining Date</label>
//                   <input
//                     type="date"
//                     className="form-control"
//                     value={joiningDate}
//                     onChange={handleJoiningDateChange}
//                   />
//                 </div>
//                 <div className="form-group">
//                   <label>Payout Possible</label>
//                   <select className="form-control" value={payoutPossible} onChange={handlePayoutPossibleChange}>
//                     <option value="">Select option</option>
//                     <option value="yes">Yes</option>
//                     <option value="no">No</option>
//                     <option value="not applicable">Not Applicable</option>
//                   </select>
//                 </div>
//               </>
//             )}
//           </Modal.Body>
//           <Modal.Footer>
//             <Button variant="secondary" onClick={handleCloseDetailsModal}>
//               Close
//             </Button>
//             <Button variant="primary" onClick={handleSubmit}>
//               Submit
//             </Button>
//           </Modal.Footer>
//         </Modal>
//       )}
//     </div>
//   );
// }

// export default ListAllCandidate;












// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { toast, ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import './UserPage.css';
// import InterviewScheduleModal from './InterviewScheduleModal';
// import { Card, Button, Modal, Form } from 'react-bootstrap';
// import { FaEye, FaFileAlt, FaCalendarAlt } from 'react-icons/fa';

// function ListAllCandidate() {
//   const [registrations, setRegistrations] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedCandidate, setSelectedCandidate] = useState(null);
//   const [viewingResume, setViewingResume] = useState(false);
//   const [detailsModal, setDetailsModal] = useState(false);
//   const [remarks, setRemarks] = useState([]);
//   const [applicationStatus, setApplicationStatus] = useState('');
//   const [showAdditionalFields, setShowAdditionalFields] = useState(false);
//   const [offerLetter, setOfferLetter] = useState('');
//   const [packageOffered, setPackageOffered] = useState('');
//   const [joiningDate, setJoiningDate] = useState('');
//   const [payoutPossible, setPayoutPossible] = useState('');

//   useEffect(() => {
//     async function fetchRegistrations() {
//       try {
//         const response = await axios.get("http://localhost:8080/api/candidates");
//         setRegistrations(response.data);
//       } catch (error) {
//         console.error("Error fetching registrations:", error);
//       }
//     }

//     fetchRegistrations();
//   }, []);

//   const updateCandidateList = (updatedCandidate) => {
//     setRegistrations(prevRegistrations =>
//       prevRegistrations.map(candidate =>
//         candidate.id === updatedCandidate.id ? updatedCandidate : candidate
//       )
//     );
//   };

//   const handleShowModal = (candidate) => {
//     setSelectedCandidate(candidate);
//     setShowModal(true);
//   };

//   const handleCloseModal = () => {
//     setSelectedCandidate(null);
//     setShowModal(false);
//   };

//   const handleViewResume = (candidateId) => {
//     setViewingResume(true);
//     setSelectedCandidate(registrations.find(candidate => candidate.id === candidateId));
//   };

//   const handleViewDetails = (candidate) => {
//     setSelectedCandidate(candidate);
//     fetchRemarks(candidate.id);
//     setDetailsModal(true);
//   };

//   const handleCloseDetailsModal = () => {
//     setSelectedCandidate(null);
//     setDetailsModal(false);
//   };

//   const fetchRemarks = async (candidateId) => {
//     try {
//       const response = await axios.get(`http://localhost:8080/api/interview-remarks/candidate/${candidateId}`);
//       setRemarks(response.data);

//       if (response.data.length > 0) {
//         setSelectedCandidate(prevCandidate => ({
//           ...prevCandidate,
//           status: "Interview Done"
//         }));
//         updateCandidateList({
//           ...selectedCandidate,
//           status: "Interview Done"
//         });
//       }
//     } catch (error) {
//       console.error('Error fetching remarks:', error);
//     }
//   };

//   const handleStatusChange = (e) => {
//     const status = e.target.value;
//     setApplicationStatus(status);
//     setShowAdditionalFields(status === "shortlisted" || status === "shortlisted-high-package"||status==="reject");
//   };

//   const handleOfferLetterChange = (e) => {
//     setOfferLetter(e.target.value);
//   };

//   const handlePackageOfferedChange = (e) => {
//     setPackageOffered(e.target.value);
//   };

//   const handleJoiningDateChange = (e) => {
//     setJoiningDate(e.target.value);
//   };

//   const handlePayoutPossibleChange = (e) => {
//     setPayoutPossible(e.target.value);
//   };

//   const handleSubmit = async () => {
//     try {
//       let endpoint = "";
//       switch (applicationStatus) {
//         case "rejected":
//           endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/reject`;
//           break;
//         case "shortlisted":
//           endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/shortlist`;
//           break;
//         case "shortlisted-high-package":
//           endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/shortlist-high-package`;
//           break;
//         default:
//           console.error("Invalid application status selected");
//           return;
//       }

//       const response = await axios.put(endpoint, {
//         offerLetter: offerLetter,
//         packageOffered: packageOffered,
//         joiningDate: joiningDate,
//         payoutPossible: payoutPossible
//       });

//       const updatedCandidate = {
//         ...selectedCandidate,
//         status: applicationStatus
//       };

//       updateCandidateList(updatedCandidate);

//       toast.success('Candidate status updated successfully');
//       handleCloseDetailsModal();
//     } catch (error) {
//       console.error('Error updating candidate status:', error);
//       toast.error('Failed to update candidate status. Please try again.');
//     }
//   };

//   return (
//     <div className="user-page">
//       <ToastContainer position="top-center" />
//       <div className="card-container">
//         {registrations.map((candidate) => (
//           <Card key={candidate.id} className="candidate-card">
//             <Card.Body>
//               <Card.Title>{candidate.name}</Card.Title>
//               <Card.Subtitle className="mb-2 text-muted">{candidate.email}</Card.Subtitle>
//               <Card.Text>
//                 Phone: {candidate.phone}<br />
//                 Designation: {candidate.designation}<br />
//                 Qualification: {candidate.qualification}
//                 {candidate.status && (
//                   <p><strong>Status: {candidate.result}</strong></p>
//                 )}
//               </Card.Text>
//               <Button variant="secondary" onClick={() => handleViewResume(candidate.id)}>
//                 <FaFileAlt /> Resume
//               </Button>
//               <Button variant="info" className="ml-2" onClick={() => handleViewDetails(candidate)}>
//                 <FaEye /> Details
//               </Button>
//               {candidate.status === "Scheduled" ? (
//                 <Button variant="success" disabled className="ml-2">
//                   <FaCalendarAlt /> Interview Scheduled
//                 </Button>
//               ) : candidate.status === "Interview Done" ? (
//                 <Button variant="success" disabled className="ml-2">
//                   <FaCalendarAlt /> Interview Done
//                 </Button>
//               ) : (
//                 <Button
//                   variant="secondary"
//                   className="ml-2 mt-2"
//                   onClick={() => handleShowModal(candidate)}
//                 >
//                   <FaCalendarAlt /> Interview Schedule
//                 </Button>
//               )}
//             </Card.Body>
//           </Card>
//         ))}
//       </div>
//       {selectedCandidate && (
//         <InterviewScheduleModal
//           show={showModal}
//           handleClose={handleCloseModal}
//           candidate={selectedCandidate}
//           updateCandidateList={updateCandidateList}
//         />
//       )}
//       {viewingResume && selectedCandidate && (
//         <div className="modal" style={{ display: 'block', backgroundColor: 'rgba(0, 0, 0, 0.5)', position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 9999 }}>
//           <div className="modal-dialog" style={{ width: '80%', maxWidth: '800px', margin: '30px auto' }}>
//             <div className="modal-content">
//               <div className="modal-header">
//                 <h5 className="modal-title">Resume for {selectedCandidate.name}</h5>
//                 <button type="button" className="close" onClick={() => setViewingResume(false)}>
//                   <span>&times;</span>
//                 </button>
//               </div>
//               <div className="modal-body">
//                 <iframe
//                   src={`data:application/pdf;base64,${selectedCandidate.resume}`}
//                   title="Resume"
//                   width="100%"
//                   height="500px"
//                 />
//               </div>
//               <div className="modal-footer">
//                 <Button variant="secondary" onClick={() => setViewingResume(false)}>
//                   Close
//                 </Button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//       <Modal show={detailsModal} onHide={handleCloseDetailsModal}>
//         <Modal.Header closeButton>
//           <Modal.Title>Candidate Details</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           {selectedCandidate && (
//             <div>
//               <p><strong>Name:</strong> {selectedCandidate.name}</p>
//               <p><strong>Email:</strong> {selectedCandidate.email}</p>
//               <p><strong>Phone:</strong> {selectedCandidate.phone}</p>
//               <p><strong>Designation:</strong> {selectedCandidate.designation}</p>
//               <p><strong>Qualification:</strong> {selectedCandidate.qualification}</p>
//               <h5>Interview Remarks:</h5>
//               {remarks.length > 0 ? (
//                 <ul>
//                   {remarks.map((remark, index) => (
//                     <li key={index}>{remark}</li>
//                   ))}
//                 </ul>
//               ) : (
//                 <p>No remarks available.</p>
//               )}
//               <Form.Group controlId="applicationStatus">
//                 <Form.Label>Application Status</Form.Label>
//                 <Form.Control
//                   as="select"
//                   value={applicationStatus}
//                   onChange={handleStatusChange}
//                 >
//                   <option value="">Select Status</option>
//                   <option value="shortlisted">Shortlisted</option>
//                   <option value="shortlisted-high-package">Shortlisted with High Package</option>
//                   <option value="rejected">Rejected</option>
//                 </Form.Control>
//               </Form.Group>
//               {showAdditionalFields && (
//                 <>
//                   <Form.Group controlId="offerLetter">
//                     <Form.Label>Offer Letter</Form.Label>
//                     <div className="radio-group">
//                       <Form.Check
//                         type="radio"
//                         label="Shared"
//                         name="offerLetter"
//                         value="Shared"
//                         checked={offerLetter === "Shared"}
//                         onChange={handleOfferLetterChange}
//                       />
//                       <Form.Check
//                         type="radio"
//                         label="Accepted"
//                         name="offerLetter"
//                         value="Accepted"
//                         checked={offerLetter === "Accepted"}
//                         onChange={handleOfferLetterChange}
//                       />
//                       <Form.Check
//                         type="radio"
//                         label="Declined"
//                         name="offerLetter"
//                         value="Declined"
//                         checked={offerLetter === "Declined"}
//                         onChange={handleOfferLetterChange}
//                       />
//                     </div>
//                   </Form.Group>
//                   <Form.Group controlId="packageOffered">
//                     <Form.Label>Package Offered</Form.Label>
//                     <Form.Control
//                       as="select"
//                       value={packageOffered}
//                       onChange={handlePackageOfferedChange}
//                     >
//                       <option value="">Select Package</option>
//                       <option value="2.5 LPA">2.5 LPA</option>
//                       <option value="3 LPA">3 LPA</option>
//                       <option value="8 LPA">8 LPA</option>
//                     </Form.Control>
//                   </Form.Group>
//                   <Form.Group controlId="joiningDate">
//                     <Form.Label>Joining Date</Form.Label>
//                     <Form.Control
//                       type="date"
//                       value={joiningDate}
//                       onChange={handleJoiningDateChange}
//                     />
//                   </Form.Group>
//                   <Form.Group controlId="payoutPossible">
//                     <Form.Label>Payout Possible</Form.Label>
//                     <Form.Control
//                       type="text"
//                       value={payoutPossible}
//                       onChange={handlePayoutPossibleChange}
//                     />
//                   </Form.Group>
//                 </>
//               )}
//             </div>
//           )}
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleCloseDetailsModal}>
//             Close
//           </Button>
//           <Button variant="primary" onClick={handleSubmit}>
//             Submit
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </div>
//   );
// }

// export default ListAllCandidate;




// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { toast, ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import './UserPage.css';
// import InterviewScheduleModal from './InterviewScheduleModal';
// import { Card, Button, Modal, Form } from 'react-bootstrap';
// import { FaEye, FaFileAlt, FaCalendarAlt } from 'react-icons/fa';

// function ListAllCandidate() {
//   const [registrations, setRegistrations] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedCandidate, setSelectedCandidate] = useState(null);
//   const [viewingResume, setViewingResume] = useState(false);
//   const [detailsModal, setDetailsModal] = useState(false);
//   const [remarks, setRemarks] = useState([]);
//   const [applicationStatus, setApplicationStatus] = useState('');
//   const [showAdditionalFields, setShowAdditionalFields] = useState(false);
//   const [offerLetter, setOfferLetter] = useState('');
//   const [packageOffered, setPackageOffered] = useState('');
//   const [joiningDate, setJoiningDate] = useState('');
//   const [payoutPossible, setPayoutPossible] = useState('');

//   useEffect(() => {
//     async function fetchRegistrations() {
//       try {
//         const response = await axios.get("http://localhost:8080/api/candidates");
//         setRegistrations(response.data);
//       } catch (error) {
//         console.error("Error fetching registrations:", error);
//       }
//     }

//     fetchRegistrations();
//   }, []);

//   const updateCandidateList = (updatedCandidate) => {
//     setRegistrations(prevRegistrations =>
//       prevRegistrations.map(candidate =>
//         candidate.id === updatedCandidate.id ? updatedCandidate : candidate
//       )
//     );
//   };

//   const handleShowModal = (candidate) => {
//     setSelectedCandidate(candidate);
//     setShowModal(true);
//   };

//   const handleCloseModal = () => {
//     setSelectedCandidate(null);
//     setShowModal(false);
//   };

//   const handleViewResume = (candidateId) => {
//     setViewingResume(true);
//     setSelectedCandidate(registrations.find(candidate => candidate.id === candidateId));
//   };

//   const handleViewDetails = (candidate) => {
//     setSelectedCandidate(candidate);
//     fetchRemarks(candidate.id);
//     setDetailsModal(true);
//   };

//   const handleCloseDetailsModal = () => {
//     setSelectedCandidate(null);
//     setDetailsModal(false);
//   };

//   const fetchRemarks = async (candidateId) => {
//     try {
//       const response = await axios.get(`http://localhost:8080/api/interview-remarks/candidate/${candidateId}`);
//       setRemarks(response.data);

//       if (response.data.length > 0) {
//         setSelectedCandidate(prevCandidate => ({
//           ...prevCandidate,
//           status: "Interview Done"
//         }));
//         updateCandidateList({
//           ...selectedCandidate,
//           status: "Interview Done"
//         });
//       }
//     } catch (error) {
//       console.error('Error fetching remarks:', error);
//     }
//   };

//   const handleStatusChange = (e) => {
//     const status = e.target.value;
//     setApplicationStatus(status);
//     setShowAdditionalFields(status === "shortlisted" || status === "shortlisted-high-package"||status==="reject");
//   };

//   const handleOfferLetterChange = (e) => {
//     setOfferLetter(e.target.value);
//   };

//   const handlePackageOfferedChange = (e) => {
//     setPackageOffered(e.target.value);
//   };

//   const handleJoiningDateChange = (e) => {
//     setJoiningDate(e.target.value);
//   };

//   const handlePayoutPossibleChange = (e) => {
//     setPayoutPossible(e.target.value);
//   };

//   const handleSubmit = async () => {
//     try {
//       let endpoint = "";
//       switch (applicationStatus) {
//         case "rejected":
//           endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/reject`;
//           break;
//         case "shortlisted":
//           endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/shortlist`;
//           break;
//         case "shortlisted-high-package":
//           endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/shortlist-high-package`;
//           break;
//         default:
//           console.error("Invalid application status selected");
//           return;
//       }

//       const response = await axios.put(endpoint, {
//         offerLetter: offerLetter,
//         packageOffered: packageOffered,
//         joiningDate: joiningDate,
//         payoutPossible: payoutPossible
//       });

//       const updatedCandidate = {
//         ...selectedCandidate,
//         status: applicationStatus
//       };

//       updateCandidateList(updatedCandidate);

//       toast.success('Candidate status updated successfully');
//       handleCloseDetailsModal();
//     } catch (error) {
//       console.error('Error updating candidate status:', error);
//       toast.error('Failed to update candidate status. Please try again.');
//     }
//   };

//   return (
//     <div className="user-page">
//       <ToastContainer position="top-center" />
//       <div className="card-container">
//         {registrations.map((candidate) => (
//           <Card key={candidate.id} className="candidate-card">
//             <Card.Body>
//               <Card.Title>{candidate.name}</Card.Title>
//               <Card.Subtitle className="mb-2 text-muted">{candidate.email}</Card.Subtitle>
//               <Card.Text>
//                 Phone: {candidate.phone}<br />
//                 Designation: {candidate.designation}<br />
//                 Qualification: {candidate.qualification}
//                 {candidate.status && (
//                  <p><strong>Status: {candidate.result}</strong></p>
//                 )}
//               </Card.Text>
//               <Button variant="secondary" onClick={() => handleViewResume(candidate.id)}>
//                 <FaFileAlt /> Resume
//               </Button>
//               <Button variant="info" className="ml-2" onClick={() => handleViewDetails(candidate)}>
//                 <FaEye /> Details
//               </Button>
//               {candidate.status === "Scheduled" ? (
//                 <Button variant="success" disabled className="ml-2">
//                   <FaCalendarAlt /> Interview Scheduled
//                 </Button>
//               ) : candidate.status === "Interview Done" ? (
//                 <Button variant="success" disabled className="ml-2">
//                   <FaCalendarAlt /> Interview Done
//                 </Button>
//               ) : (
//                 <Button
//                   variant="secondary"
//                   className="ml-2 mt-2"
//                   onClick={() => handleShowModal(candidate)}
//                 >
//                   <FaCalendarAlt /> Interview Schedule
//                 </Button>
//               )}
//             </Card.Body>
//           </Card>
//         ))}
//       </div>
//       {selectedCandidate && (
//         <InterviewScheduleModal
//           show={showModal}
//           handleClose={handleCloseModal}
//           candidate={selectedCandidate}
//           updateCandidateList={updateCandidateList}
//         />
//       )}
//       {viewingResume && selectedCandidate && (
//         <div className="modal" style={{ display: 'block', backgroundColor: 'rgba(0, 0, 0, 0.5)', position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 9999 }}>
//           <div className="modal-dialog" style={{ width: '80%', maxWidth: '800px', margin: '30px auto' }}>
//             <div className="modal-content">
//               <div className="modal-header">
//                 <h5 className="modal-title">Resume for {selectedCandidate.name}</h5>
//                 <button type="button" className="close" onClick={() => setViewingResume(false)}>
//                   <span>&times;</span>
//                 </button>
//               </div>
//               <div className="modal-body">
//                 <iframe
//                   src={`data:application/pdf;base64,${selectedCandidate.resume}`}
//                   title="Resume"
//                   width="100%"
//                   height="500px"
//                 />
//               </div>
//               <div className="modal-footer">
//                 <Button variant="secondary" onClick={() => setViewingResume(false)}>
//                   Close
//                 </Button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//       <Modal show={detailsModal} onHide={handleCloseDetailsModal}>
//         <Modal.Header closeButton>
//           <Modal.Title>Candidate Details</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           {selectedCandidate && (
//             <div>
//               <p><strong>Name:</strong> {selectedCandidate.name}</p>
//               <p><strong>Email:</strong> {selectedCandidate.email}</p>
//               <p><strong>Phone:</strong> {selectedCandidate.phone}</p>
//               <p><strong>Designation:</strong> {selectedCandidate.designation}</p>
//               <p><strong>Qualification:</strong> {selectedCandidate.qualification}</p>
//               <h5>Interview Remarks:</h5>
//               {remarks.length > 0 ? (
//                 <ul>
//                   {remarks.map((remark, index) => (
//                     <li key={index}>
//                       <p><strong>ID:</strong> {remark.id}</p>
//                       <p><strong>Candidate:</strong> {remark.candidate}</p>
//                       <p><strong>Interview:</strong> {remark.interview}</p>
//                       <p><strong>Interviewer Name:</strong> {remark.interviewerName}</p>
//                       <p><strong>Remark:</strong> {remark.remark}</p>
//                       <p><strong>Timestamp:</strong> {remark.timestamp}</p>
//                       <p><strong>Interviewer Email:</strong> {remark.interviewerEmail}</p>
//                     </li>
//                   ))}
//                 </ul>
//               ) : (
//                 <p>No remarks available.</p>
//               )}
//               <Form.Group controlId="applicationStatus">
//                 <Form.Label>Application Status</Form.Label>
//                 <Form.Control
//                   as="select"
//                   value={applicationStatus}
//                   onChange={handleStatusChange}
//                 >
//                   <option value="">Select Status</option>
//                   <option value="shortlisted">Shortlisted</option>
//                   <option value="shortlisted-high-package">Shortlisted with High Package</option>
//                   <option value="rejected">Rejected</option>
//                 </Form.Control>
//               </Form.Group>
//               {showAdditionalFields && (
//                 <>
//                   <Form.Group controlId="offerLetter">
//                     <Form.Label>Offer Letter</Form.Label>
//                     <div className="radio-group">
//                       <Form.Check
//                         type="radio"
//                         label="Shared"
//                         name="offerLetter"
//                         value="Shared"
//                         checked={offerLetter === "Shared"}
//                         onChange={handleOfferLetterChange}
//                       />
//                       <Form.Check
//                         type="radio"
//                         label="Accepted"
//                         name="offerLetter"
//                         value="Accepted"
//                         checked={offerLetter === "Accepted"}
//                         onChange={handleOfferLetterChange}
//                       />
//                       <Form.Check
//                         type="radio"
//                         label="Declined"
//                         name="offerLetter"
//                         value="Declined"
//                         checked={offerLetter === "Declined"}
//                         onChange={handleOfferLetterChange}
//                       />
//                     </div>
//                   </Form.Group>
//                   <Form.Group controlId="packageOffered">
//                     <Form.Label>Package Offered</Form.Label>
//                     <Form.Control
//                       as="select"
//                       value={packageOffered}
//                       onChange={handlePackageOfferedChange}
//                     >
//                       <option value="">Select Package</option>
//                       <option value="2.5 LPA">2.5 LPA</option>
//                       <option value="3 LPA">3 LPA</option>
//                       <option value="8 LPA">8 LPA</option>
//                     </Form.Control>
//                   </Form.Group>
//                   <Form.Group controlId="joiningDate">
//                     <Form.Label>Joining Date</Form.Label>
//                     <Form.Control
//                       type="date"
//                       value={joiningDate}
//                       onChange={handleJoiningDateChange}
//                     />
//                   </Form.Group>
//                   <Form.Group controlId="payoutPossible">
//                     <Form.Label>Payout Possible</Form.Label>
//                     <Form.Control
//                       type="text"
//                       value={payoutPossible}
//                       onChange={handlePayoutPossibleChange}
//                     />
//                   </Form.Group>
//                 </>
//               )}
//             </div>
//           )}
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleCloseDetailsModal}>
//             Close
//           </Button>
//           <Button variant="primary" onClick={handleSubmit}>
//             Save Changes
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </div>
//   );
// }

// export default ListAllCandidate;





import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './UserPage.css';
import InterviewScheduleModal from './InterviewScheduleModal';
import { Card, Button, Modal, Form } from 'react-bootstrap';
import { FaEye, FaFileAlt, FaCalendarAlt } from 'react-icons/fa';

function ListAllCandidate() {
  const [registrations, setRegistrations] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [viewingResume, setViewingResume] = useState(false);
  const [detailsModal, setDetailsModal] = useState(false);
  const [remarks, setRemarks] = useState([]);
  const [applicationStatus, setApplicationStatus] = useState('');
  const [showAdditionalFields, setShowAdditionalFields] = useState(false);
  const [offerLetter, setOfferLetter] = useState('');
  const [packageOffered, setPackageOffered] = useState('');
  const [joiningDate, setJoiningDate] = useState('');
  const [payoutPossible, setPayoutPossible] = useState('');

  useEffect(() => {
    async function fetchRegistrations() {
      try {
        const response = await axios.get("http://localhost:8080/api/candidates");
        console.log(response.data)
        setRegistrations(response.data);
      } catch (error) {
        console.error("Error fetching registrations:", error);
      }
    }

    fetchRegistrations();
  }, []);

  const updateCandidateList = (updatedCandidate) => {
    setRegistrations(prevRegistrations =>
      prevRegistrations.map(candidate =>
        candidate.id === updatedCandidate.id ? updatedCandidate : candidate
      )
    );
  };

  const handleShowModal = (candidate) => {
    setSelectedCandidate(candidate);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setSelectedCandidate(null);
    setShowModal(false);
  };

  const handleViewResume = (candidateId) => {
    setViewingResume(true);
    setSelectedCandidate(registrations.find(candidate => candidate.id === candidateId));
  };

  const handleViewDetails = (candidate) => {
    setSelectedCandidate(candidate);
    fetchRemarks(candidate.id);
    setDetailsModal(true);
  };

  const handleCloseDetailsModal = () => {
    setSelectedCandidate(null);
    setDetailsModal(false);
  };

  const fetchRemarks = async (candidateId) => {
    try {
      const response = await axios.get(`http://localhost:8080/api/interview-remarks/candidate/${candidateId}`);
      setRemarks(response.data);

      if (response.data.length > 0) {
        updateCandidateList(prevRegistrations => prevRegistrations.map(candidate => (
          candidate.id === selectedCandidate.id ? { ...candidate, status: "Interview Done" } : candidate
        )));
      }
    } catch (error) {
      console.error('Error fetching remarks:', error);
    }
  };

  const handleStatusChange = (e) => {
    const status = e.target.value;
    setApplicationStatus(status);
    setShowAdditionalFields(status === "shortlisted" || status === "shortlisted-high-package" || status === "rejected");
  };

  const handleOfferLetterChange = (e) => {
    setOfferLetter(e.target.value);
  };

  const handlePackageOfferedChange = (e) => {
    setPackageOffered(e.target.value);
  };

  const handleJoiningDateChange = (e) => {
    setJoiningDate(e.target.value);
  };

  const handlePayoutPossibleChange = (e) => {
    setPayoutPossible(e.target.value);
  };

  const handleSubmit = async () => {
    try {
      let endpoint = "";
      switch (applicationStatus) {
        case "rejected":
          endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/reject`;
          break;
        case "shortlisted":
          endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/shortlist`;
          break;
        case "shortlisted-high-package":
          endpoint = `http://localhost:8080/api/candidates/${selectedCandidate.id}/shortlist-high-package`;
          break;
        default:
          console.error("Invalid application status selected");
          return;
      }

      const response = await axios.put(endpoint, {
        offerLetter: offerLetter,
        packageOffered: packageOffered,
        joiningDate: joiningDate,
        payoutPossible: payoutPossible
      });

      const updatedCandidate = {
        ...selectedCandidate,
        status: applicationStatus
      };

      updateCandidateList(updatedCandidate);

      toast.success('Candidate status updated successfully');
      handleCloseDetailsModal();
    } catch (error) {
      console.error('Error updating candidate status:', error);
      toast.error('Failed to update candidate status. Please try again.');
    }
  };

  return (
    <div className="user-page">
      
      <ToastContainer position="top-center" />
      <div className="card-container">
        {registrations.map((candidate) => (
          
          <Card key={candidate.id} className="candidate-card">
            <Card.Body>
              <Card.Title>{candidate.name}</Card.Title>
              <Card.Subtitle className="mb-2 text-muted">{candidate.email}</Card.Subtitle>
              <Card.Text>
                Phone: {candidate.phone}<br />
                Designation: {candidate.designation}<br />
                Qualification: {candidate.qualification}
                {candidate.status && (
                  <p><strong>Status: {candidate.result}</strong></p>
                )}
              </Card.Text>
              <Button variant="secondary" onClick={() => handleViewResume(candidate.id)}>
                <FaFileAlt /> Resume
              </Button>
              <Button variant="info" className="ml-2" onClick={() => handleViewDetails(candidate)}>
                <FaEye /> Details
              </Button>
              {candidate.status === "Scheduled" ? (
                <Button variant="success" disabled className="ml-2">
                  <FaCalendarAlt /> Interview Scheduled
                </Button>
              ) : candidate.status === "Interview Done" ? (
                <Button variant="success" disabled className="ml-2">
                  <FaCalendarAlt /> Interview Done
                </Button>
              ) : (
                <Button
                  variant="secondary"
                  className="ml-2 mt-2"
                  onClick={() => handleShowModal(candidate)}
                >
                  <FaCalendarAlt /> Interview Schedule
                </Button>
              )}
            </Card.Body>
          </Card>
        ))}
      </div>
      {selectedCandidate && (
        <InterviewScheduleModal
          show={showModal}
          handleClose={handleCloseModal}
          candidate={selectedCandidate}
          updateCandidateList={updateCandidateList}
        />
      )}
      {viewingResume && selectedCandidate && (
        <div className="modal" style={{ display: 'block', backgroundColor: 'rgba(0, 0, 0, 0.5)', position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 9999 }}>
          <div className="modal-dialog" style={{ width: '80%', maxWidth: '800px', margin: '30px auto' }}>
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Resume for {selectedCandidate.name}</h5>
                <button type="button" className="close" onClick={() => setViewingResume(false)}>
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                <iframe
                  src={`data:application/pdf;base64,${selectedCandidate.resume}`}
                  title="Resume"
                  width="100%"
                  height="500px"
                />
              </div>
              <div className="modal-footer">
                <Button variant="secondary" onClick={() => setViewingResume(false)}>
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      <Modal show={detailsModal} onHide={handleCloseDetailsModal}>
        <Modal.Header closeButton>
          <Modal.Title>Candidate Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedCandidate && (
            <div>
              <p><strong>Name:</strong> {selectedCandidate.name}</p>
              <p><strong>Email:</strong> {selectedCandidate.email}</p>
              <p><strong>Phone:</strong> {selectedCandidate.phone}</p>
              <p><strong>Designation:</strong> {selectedCandidate.designation}</p>
              <p><strong>Qualification:</strong> {selectedCandidate.qualification}</p>
             


<h5>Interview Remarks:</h5>
{remarks.length > 0 ? (
  <ul>
    {remarks.map((remark, index) => (
      <li key={index}>
       
        <p><strong>Interviewer Name:</strong> {remark.interviewerName}</p>
        <p><strong>Remark:</strong> {remark.remark}</p>
        
      </li>
    ))}
  </ul>
) : (
  <p>No remarks available.</p>
)}

              <Form.Group controlId="applicationStatus">
                <Form.Label>Application Status</Form.Label>
                <Form.Control
                  as="select"
                  value={applicationStatus}
                  onChange={handleStatusChange}
                >
                  <option value="">Select Status</option>
                  <option value="shortlisted">Shortlisted</option>
                  <option value="shortlisted-high-package">Shortlisted with High Package</option>
                  <option value="rejected">Rejected</option>
                </Form.Control>
              </Form.Group>
              {showAdditionalFields && (
                <>
                  <Form.Group controlId="offerLetter">
                    <Form.Label>Offer Letter</Form.Label>
                    <div className="radio-group">
                      <Form.Check
                        type="radio"
                        label="Shared"
                        name="offerLetter"
                        value="Shared"
                        checked={offerLetter === "Shared"}
                        onChange={handleOfferLetterChange}
                      />
                      <Form.Check
                        type="radio"
                        label="Accepted"
                        name="offerLetter"
                        value="Accepted"
                        checked={offerLetter === "Accepted"}
                        onChange={handleOfferLetterChange}
                      />
                      <Form.Check
                        type="radio"
                        label="Declined"
                        name="offerLetter"
                        value="Declined"
                        checked={offerLetter === "Declined"}
                        onChange={handleOfferLetterChange}
                      />
                    </div>
                  </Form.Group>
                  <Form.Group controlId="packageOffered">
                    <Form.Label>Package Offered</Form.Label>
                    <Form.Control
                      as="select"
                      value={packageOffered}
                      onChange={handlePackageOfferedChange}
                    >
                      <option value="">Select Package</option>
                      <option value="2.5 LPA">2.5 LPA</option>
                      <option value="3 LPA">3 LPA</option>
                      <option value="8 LPA">8 LPA</option>
                    </Form.Control>
                  </Form.Group>
                  <Form.Group controlId="joiningDate">
                    <Form.Label>Joining Date</Form.Label>
                    <Form.Control
                      type="date"
                      value={joiningDate}
                      onChange={handleJoiningDateChange}
                    />
                  </Form.Group>
                  <Form.Group controlId="payoutPossible">
                    <Form.Label>Payout Possible</Form.Label>
                    <Form.Control
                      type="text"
                      value={payoutPossible}
                      onChange={handlePayoutPossibleChange}
                    />
                  </Form.Group>
                </>
              )}
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseDetailsModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSubmit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default ListAllCandidate;
