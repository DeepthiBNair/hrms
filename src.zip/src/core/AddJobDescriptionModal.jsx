import React, { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';

const AddJobDescriptionModal = ({ show, handleClose, handleAddDescription }) => {
    const [description, setDescription] = useState('');

    const handleChange = (e) => {
        setDescription(e.target.value);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        handleAddDescription(description);
        setDescription('');
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Add Job Description</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form onSubmit={handleSubmit}>
                    <Form.Group className="mb-3" controlId="jobDescription">
                        <Form.Label>Job Description</Form.Label>
                        <Form.Control
                            as="textarea"
                            rows={5}
                            value={description}
                            onChange={handleChange}
                            placeholder="Enter job description"
                            required
                        />
                    </Form.Group>
                    <Button variant="primary" type="submit">
                        Add Description
                    </Button>
                </Form>
            </Modal.Body>
        </Modal>
    );
};

export default AddJobDescriptionModal;
