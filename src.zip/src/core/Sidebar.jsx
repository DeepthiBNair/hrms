




// import React from 'react';
// import { Link } from 'react-router-dom';
// import './Sidebar.css';
// import './UserPage.css';
// import './Dashboard.css';

// const Sidebar = ({ role }) => {
//     return (
//         <div className="sidebar">
//             <div className="profile">
//                 <img src="https://via.placeholder.com/100" alt="Profile" className="profile-img" />
//                 <div className="profile-info">
//                     <h3 className="profile-name">Admin</h3>
//                     <p className="profile-email">Email: admin@gmail.com</p>
//                 </div>
//             </div>
//             <ul className="sidebar-menu">
//                 {role === "admin" && (
//                     <>
//                         <li>
//                             <Link to="/ListAllCandidate" className="sidebar-link">
//                                 All Candidates
//                             </Link>
//                         </li>
                        
//                         <li>
//                             <Link to="/Listalljobs" className="sidebar-link">
//                                 All Jobs
//                             </Link>
//                         </li>
//                     </>
//                 )}
//                 {role === "employee" && (
//                     <li>
//                         <Link to="/ScheduledInterview" className="sidebar-link">
//                             Scheduled Interviews
//                         </Link>
//                     </li>
//                 )}
//             </ul>
//         </div>
//     );
// };

// export default Sidebar;





// import React from 'react';
// import { Link } from 'react-router-dom';
// import './Sidebar.css';
// import './UserPage.css';
// import './Dashboard.css';

// const Sidebar = ({ role }) => {
//     return (
//         <div className="sidebar">
//             <div className="profile">
//                 <img src="https://via.placeholder.com/100" alt="Profile" className="profile-img" />
//                 <div className="profile-info">
//                     <h3 className="profile-name">Admin</h3>
//                     <p className="profile-email">Email: admin@gmail.com</p>
//                 </div>
//             </div>
//             <ul className="sidebar-menu">
//                 {role === "admin" && (
//                     <>
//                         <li>
//                             <Link to="/ListAllCandidate" className="sidebar-link">
//                                 All Candidates
//                             </Link>
//                         </li>
                        
//                         <li>
//                             <Link to="/Listalljobs" className="sidebar-link">
//                                 All Jobs
//                             </Link>
//                         </li>
//                     </>
//                 )}
//                 {role === "employee" && (
//                     <li>
//                         <Link to="/ScheduledInterview" className="sidebar-link">
//                             Scheduled Interviews
//                         </Link>
//                     </li>
//                 )}
//             </ul>
//         </div>
//     );
// };

// export default Sidebar;



import React from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.css';
import './UserPage.css';
import './Dashboard.css';

const Sidebar = ({ role }) => {
    return (
        <div className="sidebar">
            <div className="profile">
                <img src="https://via.placeholder.com/100" alt="Profile" className="profile-img" />
                <div className="profile-info">
                    <h3 className="profile-name">Admin</h3>
                    <p className="profile-email">Email: admin@gmail.com</p>
                </div>
            </div>
            <ul className="sidebar-menu">
                {role === "admin" && (
                    <>
                        <li>
                            <Link to="/ListAllCandidate" className="sidebar-link">
                                All Candidates
                            </Link>
                        </li>
                        <li>
                            <Link to="/ListAllJobs" className="sidebar-link">
                                All Jobs
                            </Link>
                        </li>
                    </>
                )}
                {role === "employee" && (
                    <li>
                        <Link to="/ScheduledInterview" className="sidebar-link">
                            Scheduled Interviews
                        </Link>
                    </li>
                )}
            </ul>
        </div>
    );
};

export default Sidebar;
