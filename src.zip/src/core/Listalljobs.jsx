





// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { Card, Button, Container, Row, Col, Modal, Badge } from 'react-bootstrap';
// import AddJobModal from './AddJobModal';
// import './Listalljobs.css'; // Make sure to import the CSS file for custom styling

// function Listalljobs() {
//   const [jobs, setJobs] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedJob, setSelectedJob] = useState(null);
//   const [showJobDetailsModal, setShowJobDetailsModal] = useState(false);

//   useEffect(() => {
//     fetchJobs();
//   }, []);

//   const fetchJobs = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/api/jobpostings");
//       setJobs(response.data);
//     } catch (error) {
//       console.error("Error fetching jobs:", error);
//     }
//   };

//   const handleCloseModal = () => setShowModal(false);
//   const handleShowModal = () => setShowModal(true);

//   const handleAddJob = async (newJob) => {
//     try {
//       await axios.post("http://localhost:8080/api/jobpostings", newJob);
//       fetchJobs(); // Fetch the updated list of jobs
//       handleCloseModal(); // Close modal after successful addition
//     } catch (error) {
//       console.error("Error adding job:", error);
//     }
//   };

//   const handleViewDetails = (job) => {
//     setSelectedJob(job);
//     setShowJobDetailsModal(true);
//   };

//   const handleCloseJobDetailsModal = () => {
//     setSelectedJob(null);
//     setShowJobDetailsModal(false);
//   };

//   return (
//     <div className="user-page">
//       <Container>
//         <div>
//           <h2 className="text-center mb-4">Jobs</h2>
//         </div>
//         <div className="text-left mb-4">
//           <Button className="btn btn-primary" onClick={handleShowModal}>
//             Add Job
//           </Button>
//         </div>
//         <Row>
//           {jobs.map((job) => (
//             <Col key={job.jobId} md={4} className="mb-4">
//               <Card>
//                 <Card.Body>
//                   <Card.Title>{job.jobName}</Card.Title>
//                   <Card.Subtitle className="mb-2 text-muted">Job ID: {job.jobId}</Card.Subtitle>
//                   <Button variant="primary" onClick={() => handleViewDetails(job)}>
//                     View Details
//                   </Button>
//                 </Card.Body>
//               </Card>
//             </Col>
//           ))}
//         </Row>
//       </Container>
      
//       {/* Add Job Modal */}
//       <AddJobModal show={showModal} handleClose={handleCloseModal} handleAddJob={handleAddJob} />

//       {/* Job Details Modal */}
//       <Modal show={showJobDetailsModal} onHide={handleCloseJobDetailsModal} fullscreen={true}>
//         <Modal.Header closeButton>
//           <Modal.Title>Job Details</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           {selectedJob && (
//             <div className="job-details-modal">
//               <h2>{selectedJob.jobName}</h2>
//               <p className="text-muted">Job ID: {selectedJob.jobId}</p>
//               <div className="tags">
//                 {selectedJob.neededSkills.split(',').map((skill, index) => (
//                   <Badge key={index} bg="info" className="tag">{skill.trim()}</Badge>
//                 ))}
//               </div>
//               <div className="job-info">
//                 <p><strong>Experience:</strong> {selectedJob.experience}</p>
//                 <p><strong>Closing Date:</strong> {selectedJob.closingDate}</p>
//                 <p><strong>Openings:</strong> {selectedJob.openings}</p>
//                 <p><strong>Status:</strong> {selectedJob.status}</p>
//                 <p><strong>Job Description:</strong> {selectedJob.jobDescription}</p>
//                 <ul>
//                   {selectedJob.responsibility.split('\n').map((resp, index) => (
//                     <li key={index}>{resp.trim()}</li>
//                   ))}
//                 </ul>
//               </div>
//             </div>
//           )}
//         </Modal.Body>
//       </Modal>
//     </div>
//   );
// }

// export default Listalljobs;



// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import Sidebar from './Sidebar';
// import { Card, Button, Container, Row, Col, Modal, Badge } from 'react-bootstrap';
// import AddJobModal from './AddJobModal';
// import './Listalljobs.css'; 
// // import './UserPage.css';// Make sure to import the CSS file for custom styling

// function Listalljobs() {
//   const [jobs, setJobs] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedJob, setSelectedJob] = useState(null);
//   const [showJobDetailsModal, setShowJobDetailsModal] = useState(false);

//   useEffect(() => {
//     fetchJobs();
//   }, []);

//   const fetchJobs = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/api/jobpostings");
//       setJobs(response.data);
//     } catch (error) {
//       console.error("Error fetching jobs:", error);
//     }
//   };

//   const handleCloseModal = () => setShowModal(false);
//   const handleShowModal = () => setShowModal(true);

//   const handleAddJob = async (newJob) => {
//     try {
//       await axios.post("http://localhost:8080/api/jobpostings", newJob);
//       fetchJobs(); // Fetch the updated list of jobs
//       handleCloseModal(); // Close modal after successful addition
//     } catch (error) {
//       console.error("Error adding job:", error);
//     }
//   };

//   const handleViewDetails = (job) => {
//     setSelectedJob(job);
//     setShowJobDetailsModal(true);
//   };

//   const handleCloseJobDetailsModal = () => {
//     setSelectedJob(null);
//     setShowJobDetailsModal(false);
//   };

//   return (
    

//     <div className="user-page">
//     {/* <Sidebar/> */}
//     <div className="main-content">
//       {/* <Container> */}
        
//           {/* <h2 className="text-center mt-5">Jobs</h2> */}
        
//         <div className="text-left mt-6 mb-4">
//           <Button className="btn btn-primary" onClick={handleShowModal}>
//             Add Job
//           </Button>
//         </div>
//         <Row>
          
//           {jobs.map((job) => (
//             <Col key={job.jobId} md={3} className="mb-4 mt-8">
//               <Card>
//                 <Card.Body>
//                   <Card.Title>{job.jobName}</Card.Title>
//                   <Card.Subtitle className="mb-2 text-muted">Job ID: {job.jobId}</Card.Subtitle>
//                   <Button variant="primary" onClick={() => handleViewDetails(job)}>
//                     View Details
//                   </Button>
//                 </Card.Body>
//               </Card>
//             </Col>
//           ))}
//         </Row>
//       {/* </Container> */}
      
//       {/* Add Job Modal */}
//       <AddJobModal show={showModal} handleClose={handleCloseModal} handleAddJob={handleAddJob} />

//       {/* Job Details Modal */}
//       <Modal show={showJobDetailsModal} onHide={handleCloseJobDetailsModal} centered>
//         <Modal.Header closeButton>
//           <Modal.Title>Job Details</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           {selectedJob && (
//             <div className="job-details-modal">
//               <h2>{selectedJob.jobName}</h2>
//               <p className="text-muted">Job ID: {selectedJob.jobId}</p>
//               <div className="tags">
//                 {selectedJob.neededSkills.split(',').map((skill, index) => (
//                   <Badge key={index} bg="info" className="tag">{skill.trim()}</Badge>
//                 ))}
//               </div>
//               <div className="job-info">
//                 <p><strong>Experience:</strong> {selectedJob.experience}</p>
//                 <p><strong>Closing Date:</strong> {selectedJob.closingDate}</p>
//                 <p><strong>Openings:</strong> {selectedJob.openings}</p>
//                 <p><strong>Status:</strong> {selectedJob.status}</p>
//                 <p><strong>Job Description:</strong> {selectedJob.jobDescription}</p>
//                 <p><strong>Responsibility:</strong> {selectedJob.responsibility}</p>
//                 {/* <ul>
//                   {selectedJob.responsibility.split('\n').map((resp, index) => (
//                     <li key={index}>{resp.trim()}</li>
//                   ))}
//                 </ul> */}
//               </div>
//             </div>
//           )}
//         </Modal.Body>
//       </Modal>
//     </div></div>
    
//   )};

// export default Listalljobs;



// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import Sidebar from './Sidebar';
// import { Card, Button, Row, Col, Modal, Badge } from 'react-bootstrap';
// import AddJobModal from './AddJobModal';
// import './Listalljobs.css';

// function Listalljobs() {
//   const [jobs, setJobs] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedJob, setSelectedJob] = useState(null);
//   const [showJobDetailsModal, setShowJobDetailsModal] = useState(false);

//   useEffect(() => {
//     fetchJobs();
//   }, []);

//   const fetchJobs = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/api/jobpostings");
//       setJobs(response.data);
//     } catch (error) {
//       console.error("Error fetching jobs:", error);
//     }
//   };

//   const handleCloseModal = () => setShowModal(false);
//   const handleShowModal = () => setShowModal(true);

//   const handleAddJob = async (newJob) => {
//     try {
//       await axios.post("http://localhost:8080/api/jobpostings", newJob);
//       fetchJobs(); // Fetch the updated list of jobs
//       handleCloseModal(); // Close modal after successful addition
//     } catch (error) {
//       console.error("Error adding job:", error);
//     }
//   };

//   const handleViewDetails = (job) => {
//     setSelectedJob(job);
//     setShowJobDetailsModal(true);
//   };

//   const handleCloseJobDetailsModal = () => {
//     setSelectedJob(null);
//     setShowJobDetailsModal(false);
//   };

//   return (
//     <div className="user-page">
//       {/* <Sidebar/> */}
//       <div className="main-content">
//         <div className="text-left mt-6 mb-4">
//           <Button className="btn btn-primary" onClick={handleShowModal}>
//             Add Job
//           </Button>
//         </div>
//         <Row>
//           {jobs.map((job) => (
//             <Col key={job.jobId} md={3} className="mb-4">
//               <Card>
//                 <Card.Body>
//                   <Card.Title>{job.jobName}</Card.Title>
//                   <Card.Subtitle className="mb-2 text-muted">Job ID: {job.jobId}</Card.Subtitle>
//                   <Button variant="primary" onClick={() => handleViewDetails(job)}>
//                     View Details
//                   </Button>
//                 </Card.Body>
//               </Card>
//             </Col>
//           ))}
//         </Row>
//         <AddJobModal show={showModal} handleClose={handleCloseModal} handleAddJob={handleAddJob} />
//         <Modal show={showJobDetailsModal} onHide={handleCloseJobDetailsModal} centered>
//           <Modal.Header closeButton>
//             <Modal.Title>Job Details</Modal.Title>
//           </Modal.Header>
//           <Modal.Body>
//             {selectedJob && (
//               <div className="job-details-modal">
//                 <h2>{selectedJob.jobName}</h2>
//                 <p className="text-muted">Job ID: {selectedJob.jobId}</p>
//                 <div className="tags">
//                   {selectedJob.neededSkills.split(',').map((skill, index) => (
//                     <Badge key={index} bg="info" className="tag">{skill.trim()}</Badge>
//                   ))}
//                 </div>
//                 <div className="job-info">
//                   <p><strong>Experience:</strong> {selectedJob.experience}</p>
//                   <p><strong>Closing Date:</strong> {selectedJob.closingDate}</p>
//                   <p><strong>Openings:</strong> {selectedJob.openings}</p>
//                   <p><strong>Status:</strong> {selectedJob.status}</p>
//                   <p><strong>Job Description:</strong> {selectedJob.jobDescription}</p>
//                   <p><strong>Responsibility:</strong> {selectedJob.responsibility}</p>
//                 </div>
//               </div>
//             )}
//           </Modal.Body>
//         </Modal>
//       </div>
//     </div>
//   );
// }

// export default Listalljobs;




// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import Sidebar from './Sidebar';
// import { Card, Button, Row, Col, Modal, Badge } from 'react-bootstrap';
// import AddJobModal from './AddJobModal';
// import './Listalljobs.css';

// function Listalljobs() {
//   const [jobs, setJobs] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedJob, setSelectedJob] = useState(null);
//   const [showJobDetailsModal, setShowJobDetailsModal] = useState(false);

//   useEffect(() => {
//     fetchJobs();
//   }, []);

//   const fetchJobs = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/api/jobpostings");
//       setJobs(response.data);
//     } catch (error) {
//       console.error("Error fetching jobs:", error);
//     }
//   };

//   const handleCloseModal = () => setShowModal(false);
//   const handleShowModal = () => setShowModal(true);

//   const handleAddJob = async (newJob) => {
//     try {
//       await axios.post("http://localhost:8080/api/jobpostings", newJob);
//       fetchJobs(); // Fetch the updated list of jobs
//       handleCloseModal(); // Close modal after successful addition
//     } catch (error) {
//       console.error("Error adding job:", error);
//     }
//   };

//   const handleViewDetails = (job) => {
//     setSelectedJob(job);
//     setShowJobDetailsModal(true);
//   };

//   const handleCloseJobDetailsModal = () => {
//     setSelectedJob(null);
//     setShowJobDetailsModal(false);
//   };

//   return (
//     <div className="d-flex">
//       <Sidebar role="admin" />
//       <div className="main-content flex-grow-1 p-3">
//         <div className="text-left mt-6 mb-4">
//           <Button className="btn btn-primary" onClick={handleShowModal}>
//             Add Job
//           </Button>
//         </div>
//         <Row>
//           {jobs.map((job) => (
//             <Col key={job.jobId} md={3} className="mb-4">
//               <Card>
//                 <Card.Body>
//                   <Card.Title>{job.jobName}</Card.Title>
//                   <Card.Subtitle className="mb-2 text-muted">Job ID: {job.jobId}</Card.Subtitle>
//                   <Button variant="primary" onClick={() => handleViewDetails(job)}>
//                     View Details
//                   </Button>
//                 </Card.Body>
//               </Card>
//             </Col>
//           ))}
//         </Row>
//         <AddJobModal show={showModal} handleClose={handleCloseModal} handleAddJob={handleAddJob} />
//         <Modal show={showJobDetailsModal} onHide={handleCloseJobDetailsModal} centered size="lg">
//           <Modal.Header closeButton>
//             <Modal.Title>Job Details</Modal.Title>
//           </Modal.Header>
//           <Modal.Body>
//             {selectedJob && (
//               <div className="job-details-modal">
//                 <h2>{selectedJob.jobName}</h2>
//                 <p className="text-muted">Job ID: {selectedJob.jobId}</p>
//                 <div className="tags">
//                   {selectedJob.neededSkills.split(',').map((skill, index) => (
//                     <Badge key={index} bg="info" className="tag">{skill.trim()}</Badge>
//                   ))}
//                 </div>
//                 <div className="job-info">
//                   <p><strong>Experience:</strong> {selectedJob.experience}</p>
//                   <p><strong>Closing Date:</strong> {selectedJob.closingDate}</p>
//                   <p><strong>Openings:</strong> {selectedJob.openings}</p>
//                   <p><strong>Status:</strong> {selectedJob.status}</p>
//                   <p><strong>Job Description:</strong> {selectedJob.jobDescription}</p>
//                   <p><strong>Responsibility:</strong> {selectedJob.responsibility}</p>
//                 </div>
//               </div>
//             )}
//           </Modal.Body>
//         </Modal>
//       </div>
//     </div>
//   );
// }

// export default Listalljobs;



// import React, { useState, useEffect } from "react";
// import axios from "axios";
// // import Sidebar from './Sidebar';
// import { Card, Button, Row, Col, Modal, Badge } from 'react-bootstrap';
// import AddJobModal from './AddJobModal';
// import './Listalljobs.css';

// function Listalljobs() {
//   const [jobs, setJobs] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedJob, setSelectedJob] = useState(null);
//   const [showJobDetailsModal, setShowJobDetailsModal] = useState(false);

//   useEffect(() => {
//     fetchJobs();
//   }, []);

//   const fetchJobs = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/api/jobpostings");
//       setJobs(response.data);
//     } catch (error) {
//       console.error("Error fetching jobs:", error);
//     }
//   };

//   const handleCloseModal = () => setShowModal(false);
//   const handleShowModal = () => setShowModal(true);

//   const handleAddJob = async (newJob) => {
//     try {
//       await axios.post("http://localhost:8080/api/jobpostings", newJob);
//       fetchJobs(); // Fetch the updated list of jobs
//       handleCloseModal(); // Close modal after successful addition
//     } catch (error) {
//       console.error("Error adding job:", error);
//     }
//   };

//   const handleViewDetails = (job) => {
//     setSelectedJob(job);
//     setShowJobDetailsModal(true);
//   };

//   const handleCloseJobDetailsModal = () => {
//     setSelectedJob(null);
//     setShowJobDetailsModal(false);
//   };

//   return (
//     <div className="d-flex">
//       {/* <Sidebar role="admin" /> */}
//       <div className="main-content flex-grow-1 p-3">
//         <div className="text-left mt-6 mb-4">
//           <Button className="btn btn-primary" onClick={handleShowModal}>
//             Add Job
//           </Button>
//         </div>
//         <Row>
//           {jobs.map((job) => (
//             <Col key={job.jobId} md={3} className="mb-4">
//               <Card>
//                 <Card.Body>
//                   <Card.Title>{job.jobName}</Card.Title>
//                   <Card.Subtitle className="mb-2 text-muted">Job ID: {job.jobId}</Card.Subtitle>
//                   <Button variant="primary" onClick={() => handleViewDetails(job)}>
//                     View Details
//                   </Button>
//                 </Card.Body>
//               </Card>
//             </Col>
//           ))}
//         </Row>
//         <AddJobModal show={showModal} handleClose={handleCloseModal} handleAddJob={handleAddJob} />
//         <Modal show={showJobDetailsModal} onHide={handleCloseJobDetailsModal} centered size="lg">
//           <Modal.Header closeButton>
//             <Modal.Title>Job Details</Modal.Title>
//           </Modal.Header>
//           <Modal.Body>
//             {selectedJob && (
//               <div className="job-details-modal">
//                 <h2>{selectedJob.jobName}</h2>
//                 <p className="text-muted">Job ID: {selectedJob.jobId}</p>
//                 <div className="tags">
//                   {selectedJob.neededSkills.split(',').map((skill, index) => (
//                     <Badge key={index} bg="info" className="tag">{skill.trim()}</Badge>
//                   ))}
//                 </div>
//                 <div className="job-info">
//                   <p><strong>Experience:</strong> {selectedJob.experience}</p>
//                   <p><strong>Closing Date:</strong> {selectedJob.closingDate}</p>
//                   <p><strong>Openings:</strong> {selectedJob.openings}</p>
//                   <p><strong>Status:</strong> {selectedJob.status}</p>
//                   <p><strong>Job Description:</strong> {selectedJob.jobDescription}</p>
//                   <p><strong>Responsibility:</strong></p>
//                   <ul>
//                     {selectedJob.responsibility.split('.').map((responsibility, index) => (
//                       <li key={index}>{responsibility.trim()}</li>
//                     ))}
//                   </ul>
//                 </div>
//               </div>
//             )}
//           </Modal.Body>
//         </Modal>
//       </div>
//     </div>
//   );
// }

// export default Listalljobs;



import React, { useState, useEffect } from "react";
import axios from "axios";
import { Card, Button, Row, Col, Modal, Badge } from 'react-bootstrap';
import AddJobModal from './AddJobModal';
import './Listalljobs.css';

function Listalljobs() {
  const [jobs, setJobs] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [showJobDetailsModal, setShowJobDetailsModal] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/jobpostings");
      setJobs(response.data);
    } catch (error) {
      console.error("Error fetching jobs:", error);
    }
  };

  const handleCloseModal = () => setShowModal(false);
  const handleShowModal = () => setShowModal(true);

  const handleAddJob = async (newJob) => {
    try {
      await axios.post("http://localhost:8080/api/jobpostings", newJob);
      fetchJobs(); // Fetch the updated list of jobs
      handleCloseModal(); // Close modal after successful addition
    } catch (error) {
      console.error("Error adding job:", error);
    }
  };

  const handleViewDetails = (job) => {
    setSelectedJob(job);
    setShowJobDetailsModal(true);
  };

  const handleCloseJobDetailsModal = () => {
    setSelectedJob(null);
    setShowJobDetailsModal(false);
  };

  return (
    <div className="d-flex">
      <div className="main-content flex-grow-1 p-3">
        <div className="text-left mt-6 mb-4">
          <Button className="btn btn-primary" onClick={handleShowModal}>
            Add Job
          </Button>
        </div>
        <div className="card-container">
          {jobs.map((job) => (
            <Card key={job.jobId} className="card">
              <Card.Body className="card-body">
                <Card.Title>{job.jobName}</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Job ID: {job.jobId}</Card.Subtitle>
                <Button variant="primary" onClick={() => handleViewDetails(job)}>
                  View Details
                </Button>
              </Card.Body>
            </Card>
          ))}
        </div>
        <AddJobModal show={showModal} handleClose={handleCloseModal} handleAddJob={handleAddJob} />
        <Modal show={showJobDetailsModal} onHide={handleCloseJobDetailsModal} centered size="lg">
          <Modal.Header closeButton>
            <Modal.Title>Job Details</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {selectedJob && (
              <div className="job-details-modal">
                <h2>{selectedJob.jobName}</h2>
                <p className="text-muted">Job ID: {selectedJob.jobId}</p>
                <div className="tags">
                  {selectedJob.neededSkills.split(',').map((skill, index) => (
                    <Badge key={index} bg="info" className="tag">{skill.trim()}</Badge>
                  ))}
                </div>
                <div className="job-info">
                  <p><strong>Experience:</strong> {selectedJob.experience}</p>
                  <p><strong>Closing Date:</strong> {selectedJob.closingDate}</p>
                  <p><strong>Openings:</strong> {selectedJob.openings}</p>
                  <p><strong>Status:</strong> {selectedJob.status}</p>
                  <p><strong>Job Description:</strong> {selectedJob.jobDescription}</p>
                  <p><strong>Responsibility:</strong></p>
                  <ul>
                    {selectedJob.responsibility.split('.').map((responsibility, index) => (
                      <li key={index}>{responsibility.trim()}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </Modal.Body>
        </Modal>
      </div>
    </div>
  );
}

export default Listalljobs;
