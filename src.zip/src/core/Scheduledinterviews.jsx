// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './UserPage.css';

// import Sidebar from './Sidebar';

// const Scheduledinterviews = () => {
//     const [scheduledInterviews, setScheduledInterviews] = useState([]);

//     useEffect(() => {
//         fetchScheduledInterviews();
//     }, []);

//     const fetchScheduledInterviews = async () => {
//         try {
//             const response = await axios.get('http://localhost:8080/api/interviewschedules');
//             setScheduledInterviews(response.data);
//         } catch (error) {
//             console.error('Error fetching scheduled interviews:', error);
//         }
//     };

//     return (
//         <div className="user-page">
//             <Sidebar />
//             <div className="container">
//                 <h2>Scheduled Interviews</h2>
//                 {scheduledInterviews.length === 0 ? (
//                     <p>No scheduled interviews yet.</p>
//                 ) : (
//                     <table className="table">
//                         <thead>
//                             <tr>
//                                 <th>Candidate Name</th>
//                                 <th>Interviewer Name</th>
//                                 <th>Interview Date</th>
//                                 <th>Interview Time</th>
//                                 <th>Mode</th>
//                                 <th>Meeting Link</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {scheduledInterviews.map(interview => (
//                                 <tr key={interview.id}>
//                                     <td>{interview.candidateName}</td>
//                                     <td>{interview.interviewerName}</td>
//                                     <td>{interview.interviewDate}</td>
//                                     <td>{interview.interviewTime}</td>
//                                     <td>{interview.interviewMode}</td>
//                                     <td>
//                                         <a href={interview.meetingLink} target="_blank" rel="noopener noreferrer">
//                                             {interview.meetingLink}
//                                         </a>
//                                     </td>
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 )}
//             </div>
//         </div>
//     );
// };

// export default Scheduledinterviews;




import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './UserPage.css';



const Scheduledinterviews = () => {
    const [scheduledInterviews, setScheduledInterviews] = useState([]);

    useEffect(() => {
        fetchScheduledInterviews();
    }, []);

 
    const fetchScheduledInterviews = async () => {
        try {
            const response = await axios.get('http://localhost:8080/api/interviewschedules');
            const updatedInterviews = response.data.map(interview => ({
                ...interview,
                remarksAdded: interview.remarksAdded || false // Ensure remarksAdded is always initialized
            }));
            setScheduledInterviews(updatedInterviews);
        } catch (error) {
            console.error('Error fetching scheduled interviews:', error);
        }
    };
    

    const cancelInterview = async (id) => {
        if (window.confirm('Are you sure you want to cancel this interview?')) {
            try {
                await axios.delete(`http://localhost:8080/api/interviewschedules/${id}`);
                // Update scheduledInterviews state after cancellation
                const updatedInterviews = scheduledInterviews.filter(interview => interview.id !== id);
                setScheduledInterviews(updatedInterviews);
            } catch (error) {
                console.error('Error cancelling interview:', error);
            }
        }
    };

    return (
        <div className="user-page">
            {/* <Sidebar /> */}
            <div className="container">
                <h2>Scheduled Interviews</h2>
                {scheduledInterviews.length === 0 ? (
                    <p>No scheduled interviews yet.</p>
                ) : (
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Candidate Name</th>
                                <th>Interviewer Name</th>
                                <th>Interview Date</th>
                                <th>Interview Time</th>
                                <th>Mode</th>
                                <th>Meeting Link</th>
                                <th>Action</th> {/* Action column */}
                            </tr>
                        </thead>
                        <tbody>
                            {scheduledInterviews.map(interview => (
                                <tr key={interview.id}>
                                    <td>{interview.candidateName}</td>
                                    <td>{interview.interviewerName}</td>
                                    <td>{interview.interviewDate}</td>
                                    <td>{interview.interviewTime}</td>
                                    <td>{interview.interviewMode}</td>
                                    <td>
                                        <a href={interview.meetingLink} target="_blank" rel="noopener noreferrer">
                                            {interview.meetingLink}
                                        </a>
                                    </td>
                                    <td>
                                        <button
                                            onClick={() => cancelInterview(interview.id)}
                                            className="btn btn-danger"
                                        >
                                            Cancel
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};

export default Scheduledinterviews;
